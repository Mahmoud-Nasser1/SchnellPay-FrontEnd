import { Link } from "react-router-dom";
import { Shield, Twitter, Linkedin, Github, Mail, Phone, MapPin } from "lucide-react";
function PublicFooter() {
  return (
    <footer className="mt-auto bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div>
            <div className="mb-4 flex items-center gap-2">
              <div className="gradient-accent flex h-8 w-8 items-center justify-center rounded-lg shadow-glow">
                <Shield className="h-4 w-4 text-accent-foreground" />
              </div>
              <span className="font-display text-xl font-bold">
                Secure<span className="text-accent">Wallet</span>
              </span>
            </div>
            <p className="mb-4 text-sm leading-relaxed text-primary-foreground/60">
              The most secure and intuitive digital wallet platform for modern financial management.
            </p>
            <div className="flex gap-3">
              {[Twitter, Linkedin, Github].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-foreground/10 transition-colors hover:bg-accent/20"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>
          {/* Product */}
          <div>
            <h4 className="mb-4 font-display text-sm font-semibold uppercase tracking-wider text-accent">
              Product
            </h4>
            <ul className="space-y-2">
              {["Features", "Security", "Pricing", "Changelog"].map((item) => (
                <li key={item}>
                  <a
                    href="#"
                    className="text-sm text-primary-foreground/60 transition-colors hover:text-accent"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          {/* Company */}
          <div>
            <h4 className="mb-4 font-display text-sm font-semibold uppercase tracking-wider text-accent">
              Company
            </h4>
            <ul className="space-y-2">
              {[
                { label: "About Us", to: "/about" },
                { label: "Contact", to: "/contact" },
                { label: "FAQ", to: "/faq" },
                { label: "Privacy Policy", to: "/privacy" },
                { label: "Terms & Conditions", to: "/terms" },
              ].map((item) => (
                <li key={item.label}>
                  <Link
                    to={item.to}
                    className="text-sm text-primary-foreground/60 transition-colors hover:text-accent"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          {/* Contact */}
          <div>
            <h4 className="mb-4 font-display text-sm font-semibold uppercase tracking-wider text-accent">
              Contact
            </h4>
            <ul className="space-y-3">
              {[
                { Icon: Mail, text: "support@securewallet.io" },
                { Icon: Phone, text: "+1 (888) 000-WALLET" },
                { Icon: MapPin, text: "San Francisco, CA 94102" },
              ].map(({ Icon, text }) => (
                <li
                  key={text}
                  className="flex items-start gap-2 text-sm text-primary-foreground/60"
                >
                  <Icon className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                  <span>{text}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-primary-foreground/10 pt-8 md:flex-row">
          <p className="text-sm text-primary-foreground/40">
            © 2025 SecureWallet. All rights reserved.
          </p>
          <div className="flex items-center gap-1 text-xs text-primary-foreground/40">
            <Shield className="h-3 w-3 text-accent" />
            <span>256-bit SSL Encrypted · PCI DSS Compliant · SOC 2 Type II Certified</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
export { PublicFooter as default };
