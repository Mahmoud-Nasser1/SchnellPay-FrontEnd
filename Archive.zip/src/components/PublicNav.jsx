import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, Shield, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/hooks/use-theme";
import { cn } from "@/lib/utils";
const navLinks = [
  { label: "Features", href: "/#features" },
  { label: "Security", href: "/#security" },
  { label: "About", href: "/about" },
  { label: "FAQ", href: "/faq" },
  { label: "Contact", href: "/contact" },
];
function PublicNav() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <nav
      className={cn(
        "fixed left-0 right-0 top-0 z-50 transition-all duration-300",
        scrolled
          ? "border-b border-border/60 bg-card/90 shadow-sm backdrop-blur-xl"
          : "bg-transparent",
      )}
    >
      <div className="container mx-auto flex h-16 items-center justify-between gap-6 px-4">
        {/* Logo */}
        <Link to="/" className="flex shrink-0 items-center gap-2.5 font-display text-xl font-bold">
          <div className="gradient-accent flex h-8 w-8 items-center justify-center rounded-xl shadow-glow">
            <Shield className="h-4 w-4 text-accent-foreground" />
          </div>
          <span
            className={cn(
              "transition-colors",
              scrolled ? "text-foreground" : "text-primary-foreground",
            )}
          >
            Secure<span className="text-accent">Wallet</span>
          </span>
        </Link>
        {/* Desktop nav links */}
        <div className="hidden items-center gap-1 md:flex">
          {navLinks.map((l) => (
            <Link
              key={l.label}
              to={l.href}
              className={cn(
                "rounded-lg px-3.5 py-2 text-sm font-medium transition-colors",
                location.pathname === l.href
                  ? "text-accent"
                  : scrolled
                    ? "text-muted-foreground hover:bg-muted hover:text-foreground"
                    : "hover:bg-primary-foreground/8 text-primary-foreground/70 hover:text-primary-foreground",
              )}
            >
              {l.label}
            </Link>
          ))}
        </div>
        {/* Desktop actions */}
        <div className="hidden items-center gap-2 md:flex">
          <button
            onClick={toggleTheme}
            className={cn(
              "rounded-lg p-2 transition-colors",
              scrolled
                ? "text-muted-foreground hover:bg-muted hover:text-foreground"
                : "text-primary-foreground/70 hover:bg-primary-foreground/10 hover:text-primary-foreground",
            )}
            aria-label="Toggle theme"
          >
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
          <Button
            variant="ghost"
            size="sm"
            asChild
            className={cn(
              scrolled
                ? ""
                : "text-primary-foreground/80 hover:bg-primary-foreground/10 hover:text-primary-foreground",
            )}
          >
            <Link to="/login">Sign In</Link>
          </Button>
          <Button variant="accent" size="sm" asChild className="font-semibold shadow-glow">
            <Link to="/register">Get Started</Link>
          </Button>
        </div>
        {/* Mobile controls */}
        <div className="flex items-center gap-1.5 md:hidden">
          <button
            onClick={toggleTheme}
            className="rounded-lg p-2 text-primary-foreground/70 hover:text-primary-foreground"
          >
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
          <button
            onClick={() => setOpen(!open)}
            className="rounded-lg p-2 text-primary-foreground/70 hover:text-primary-foreground"
            aria-label="Toggle menu"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>
      {/* Mobile menu */}
      {open && (
        <div className="flex animate-slide-down flex-col gap-1 border-t border-border/50 bg-card/95 px-4 py-4 shadow-lg backdrop-blur-xl md:hidden">
          {navLinks.map((l) => (
            <Link
              key={l.label}
              to={l.href}
              onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-2.5 text-sm font-medium text-foreground/80 transition-colors hover:bg-muted hover:text-foreground"
            >
              {l.label}
            </Link>
          ))}
          <div className="mt-1 flex gap-2 border-t border-border/50 pt-3">
            <Button variant="outline" asChild className="flex-1">
              <Link to="/login" onClick={() => setOpen(false)}>
                Sign In
              </Link>
            </Button>
            <Button variant="accent" asChild className="flex-1">
              <Link to="/register" onClick={() => setOpen(false)}>
                Get Started
              </Link>
            </Button>
          </div>
        </div>
      )}
    </nav>
  );
}
export { PublicNav as default };
