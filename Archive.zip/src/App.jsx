import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/hooks/use-theme";
import LandingPage from "./pages/Landing";
import AboutPage from "./pages/About";
import ContactPage from "./pages/Contact";
import FAQPage from "./pages/FAQ";
import LoginPage from "./pages/auth/Login";
import RegisterPage from "./pages/auth/Register";
import OtpVerifyPage from "./pages/auth/OtpVerify";
import TwoFactorVerifyPage from "./pages/auth/TwoFactorVerify";
import ForgotPasswordPage, { ResetPasswordPage } from "./pages/auth/ForgotPassword";
import DashboardLayout from "./components/DashboardLayout";
import DashboardHome from "./pages/dashboard/DashboardHome";
import SendMoneyPage from "./pages/dashboard/SendMoney";
import ReceiveMoneyPage from "./pages/dashboard/ReceiveMoney";
import TransactionsPage from "./pages/dashboard/Transactions";
import BillsPage from "./pages/dashboard/Bills";
import FundsPage from "./pages/dashboard/Funds";
import SettingsPage from "./pages/dashboard/Settings";
import AdminOverview from "./pages/admin/AdminOverview";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminKYC from "./pages/admin/AdminKYC";
import AdminProviders from "./pages/admin/AdminProviders";
import AdminServices from "./pages/admin/AdminServices";
import AdminSettings from "./pages/admin/AdminSettings";
import NotFound from "./pages/NotFound";
const queryClient = new QueryClient();
const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            {/* Public */}
            <Route path="/" element={<LandingPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/faq" element={<FAQPage />} />
            {/* Auth */}
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/otp-verify" element={<OtpVerifyPage />} />
            <Route path="/2fa" element={<TwoFactorVerifyPage />} />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />
            <Route path="/reset-password" element={<ResetPasswordPage />} />
            {/* User Dashboard */}
            <Route path="/dashboard" element={<DashboardLayout />}>
              <Route index element={<DashboardHome />} />
              <Route path="send" element={<SendMoneyPage />} />
              <Route path="receive" element={<ReceiveMoneyPage />} />
              <Route path="transactions" element={<TransactionsPage />} />
              <Route path="bills" element={<BillsPage />} />
              <Route path="funds" element={<FundsPage />} />
              <Route path="settings" element={<SettingsPage />} />
            </Route>
            {/* Admin Dashboard */}
            <Route path="/admin" element={<DashboardLayout isAdmin />}>
              <Route index element={<AdminOverview />} />
              <Route path="users" element={<AdminUsers />} />
              <Route path="kyc" element={<AdminKYC />} />
              <Route path="transactions" element={<TransactionsPage />} />
              <Route path="providers" element={<AdminProviders />} />
              <Route path="services" element={<AdminServices />} />
              <Route path="settings" element={<AdminSettings />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);
var stdin_default = App;
export { stdin_default as default };
