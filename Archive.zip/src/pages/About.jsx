import {
  Shield,
  Award,
  Heart,
  Globe,
  ArrowRight,
  Clock,
  Users,
  Star,
  CheckCircle,
  Zap,
  TrendingUp,
  Target,
  Building2,
  Quote,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import PublicNav from "@/components/PublicNav";
import PublicFooter from "@/components/PublicFooter";
import { motion, useScroll, useTransform } from "framer-motion";
import {
  fadeUp,
  fadeDown,
  fadeLeft,
  fadeRight,
  scaleIn,
  scaleUp,
  stagger,
  viewport,
} from "@/lib/motion";
import { useRef, useEffect, useState } from "react";
const team = [
  {
    name: "Alexandra Chen",
    role: "CEO & Co-Founder",
    avatar: "AC",
    bio: "Former VP at Goldman Sachs with 15+ years in fintech.",
    color: "from-blue-600 to-blue-400",
  },
  {
    name: "Marcus Reed",
    role: "CTO & Co-Founder",
    avatar: "MR",
    bio: "Ex-Google engineer, built payment infra serving 50M+ users.",
    color: "from-emerald-600 to-emerald-400",
  },
  {
    name: "Priya Sharma",
    role: "Head of Security",
    avatar: "PS",
    bio: "Cybersecurity expert, former NSA cryptographer.",
    color: "from-purple-600 to-purple-400",
  },
  {
    name: "Carlos Vega",
    role: "Head of Design",
    avatar: "CV",
    bio: "Award-winning UX designer previously at Stripe & Airbnb.",
    color: "from-orange-600 to-orange-400",
  },
  {
    name: "Elena Kowalski",
    role: "CFO",
    avatar: "EK",
    bio: "CPA with expertise in fintech compliance & global payments.",
    color: "from-pink-600 to-pink-400",
  },
  {
    name: "David Okonkwo",
    role: "Head of Partnerships",
    avatar: "DO",
    bio: "Built strategic alliances with 200+ institutions worldwide.",
    color: "from-indigo-600 to-indigo-400",
  },
];
const timeline = [
  {
    year: "2020",
    title: "Founded",
    desc: "Two engineers left Big Tech to reimagine global payments.",
  },
  {
    year: "2021",
    title: "Seed Round \u2014 $4M",
    desc: "Launched beta with 10,000 users across 15 countries.",
  },
  {
    year: "2022",
    title: "Series A \u2014 $28M",
    desc: "Reached 500K users and expanded to 80 countries.",
  },
  {
    year: "2023",
    title: "PCI DSS Level 1",
    desc: "Obtained the highest security certification in payments.",
  },
  {
    year: "2024",
    title: "Series B \u2014 $120M",
    desc: "Crossed 1M active users. Launched virtual cards.",
  },
  {
    year: "2025",
    title: "2.4M+ Users",
    desc: "Now operating in 150+ countries with $180M daily volume.",
  },
];
const values = [
  {
    icon: Shield,
    title: "Security First",
    desc: "Every feature starts with the question: is it secure? We never compromise.",
  },
  {
    icon: Globe,
    title: "Global Access",
    desc: "Financial inclusion for all, regardless of geography or background.",
  },
  {
    icon: Heart,
    title: "User Centric",
    desc: "We obsess over making complex financial tools simple and delightful.",
  },
  {
    icon: Zap,
    title: "Speed & Reliability",
    desc: "99.99% uptime SLA. Transactions that complete in seconds, not hours.",
  },
  {
    icon: Target,
    title: "Transparency",
    desc: "No hidden fees. Clear pricing. Honest communication always.",
  },
  {
    icon: Building2,
    title: "Enterprise Grade",
    desc: "Built for individuals and businesses of all sizes worldwide.",
  },
];
const stats = [
  { label: "Active Users", value: 2.4, suffix: "M+", icon: Users },
  { label: "Daily Volume", value: 180, suffix: "M+", icon: TrendingUp },
  { label: "Countries", value: 150, suffix: "+", icon: Globe },
  { label: "Uptime SLA", value: 99.99, suffix: "%", icon: CheckCircle },
];
const testimonials = [
  {
    name: "Sofia Martinez",
    role: "CFO, TechCorp",
    avatar: "SM",
    text: "SecureWallet transformed our cross-border payroll. What took days now takes minutes.",
    stars: 5,
  },
  {
    name: "James Osei",
    role: "E-commerce Founder",
    avatar: "JO",
    text: "The virtual cards and instant transfers cut our payment costs by 40%. Incredible product.",
    stars: 5,
  },
  {
    name: "Yuki Tanaka",
    role: "Freelance Designer",
    avatar: "YT",
    text: "I receive payments from 12 countries. The currency conversion is seamless and affordable.",
    stars: 5,
  },
];
function AnimatedCounter({ target, suffix, decimals = 0 }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const [started, setStarted] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started) {
          setStarted(true);
          const duration = 1800;
          const steps = 60;
          const increment = target / steps;
          let current = 0;
          const timer = setInterval(() => {
            current = Math.min(current + increment, target);
            setCount(parseFloat(current.toFixed(decimals)));
            if (current >= target) clearInterval(timer);
          }, duration / steps);
        }
      },
      { threshold: 0.5 },
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target, started, decimals]);
  return (
    <span ref={ref}>
      {decimals > 0 ? count.toFixed(decimals) : count}
      {suffix}
    </span>
  );
}
function AboutPage() {
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const heroY = useTransform(scrollYProgress, [0, 1], [0, 120]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <PublicNav />
      <main className="flex-1 pt-16">
        {/* ── HERO ── */}
        <section
          ref={heroRef}
          className="gradient-hero relative flex min-h-[75vh] items-center overflow-hidden"
        >
          {/* Parallax BG layer */}
          <motion.div style={{ y: heroY }} className="pointer-events-none absolute inset-0">
            <div
              className="absolute bottom-0 left-0 right-0 top-0"
              style={{
                backgroundImage:
                  "linear-gradient(hsl(0 0% 100%) 1px, transparent 1px), linear-gradient(90deg, hsl(0 0% 100%) 1px, transparent 1px)",
                backgroundSize: "48px 48px",
                opacity: 0.03,
              }}
            />
            <div
              className="absolute right-10 top-20 h-[480px] w-[480px] animate-pulse-glow rounded-full opacity-[0.12]"
              style={{ background: "radial-gradient(circle, hsl(162 90% 44%), transparent)" }}
            />
            <div
              className="absolute -bottom-20 -left-10 h-[300px] w-[300px] rounded-full opacity-[0.07]"
              style={{ background: "radial-gradient(circle, hsl(213 85% 50%), transparent)" }}
            />
          </motion.div>
          <div className="container relative z-10 mx-auto px-4 py-32">
            <motion.div
              style={{ opacity: heroOpacity }}
              variants={stagger}
              initial="hidden"
              animate="visible"
              className="mx-auto max-w-4xl text-center"
            >
              <motion.div
                variants={fadeDown}
                custom={0}
                className="mb-6 inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/10 px-4 py-2"
              >
                <Award className="h-3.5 w-3.5 text-accent" />
                <span className="text-xs font-semibold uppercase tracking-wide text-accent">
                  Fintech Award Winner 2024
                </span>
              </motion.div>
              <motion.h1
                variants={fadeUp}
                custom={1}
                className="mb-6 font-display text-5xl font-bold leading-[1.05] text-primary-foreground md:text-7xl"
              >
                We're Building the Future of{" "}
                <span className="text-gradient-accent">Digital Finance</span>
              </motion.h1>
              <motion.p
                variants={fadeUp}
                custom={2}
                className="mx-auto mb-8 max-w-2xl text-xl leading-relaxed text-primary-foreground/70"
              >
                SecureWallet was founded with one mission: make global financial access safe,
                instant, and equitable for every person on Earth.
              </motion.p>
              <motion.div
                variants={fadeUp}
                custom={3}
                className="flex flex-col justify-center gap-4 sm:flex-row"
              >
                <Button variant="accent" size="lg" asChild className="group shadow-glow">
                  <Link to="/register">
                    Start Free Today{" "}
                    <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
                <Button
                  variant="ghost"
                  size="lg"
                  className="border border-primary-foreground/25 text-primary-foreground/85 hover:bg-primary-foreground/10 hover:text-primary-foreground"
                >
                  Learn More
                </Button>
              </motion.div>
            </motion.div>
          </div>
        </section>
        {/* ── STATS ── */}
        <section className="border-y border-primary-foreground/10 bg-primary py-16">
          <div className="container mx-auto px-4">
            <motion.div
              variants={stagger}
              initial="hidden"
              whileInView="visible"
              viewport={viewport}
              className="grid grid-cols-2 gap-8 md:grid-cols-4"
            >
              {stats.map(({ label, value, suffix, icon: Icon }, i) => (
                <motion.div key={label} variants={scaleIn} custom={i} className="text-center">
                  <Icon className="mx-auto mb-2 h-6 w-6 text-accent opacity-70" />
                  <p className="mb-1 font-display text-3xl font-bold text-accent md:text-4xl">
                    <AnimatedCounter
                      target={value}
                      suffix={suffix}
                      decimals={value % 1 !== 0 ? 2 : 0}
                    />
                  </p>
                  <p className="text-sm text-primary-foreground/65">{label}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>
        {/* ── MISSION ── */}
        <section className="bg-background py-24">
          <div className="container mx-auto px-4">
            <div className="mx-auto grid max-w-6xl items-center gap-16 lg:grid-cols-2">
              <motion.div
                variants={fadeLeft}
                initial="hidden"
                whileInView="visible"
                viewport={viewport}
              >
                <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-accent/20 bg-accent/10 px-3 py-1.5">
                  <Target className="h-3 w-3 text-accent" />
                  <span className="text-xs font-semibold uppercase tracking-wide text-accent">
                    Our Mission
                  </span>
                </div>
                <h2 className="mb-6 font-display text-4xl font-bold leading-tight text-foreground md:text-5xl">
                  Empowering everyone to{" "}
                  <span className="text-gradient-accent">participate in finance</span>
                </h2>
                <p className="mb-6 text-lg leading-relaxed text-muted-foreground">
                  Over 1.4 billion adults remain unbanked globally. We're changing that by building
                  technology that is borderless, secure, and accessible to everyone.
                </p>
                <p className="leading-relaxed text-muted-foreground">
                  Our platform removes the barriers — no minimum balance, no hidden fees, no
                  discrimination by geography — so every person can send, save, and grow their
                  money.
                </p>
              </motion.div>
              <motion.div
                variants={fadeRight}
                initial="hidden"
                whileInView="visible"
                viewport={viewport}
              >
                <div className="relative">
                  <div className="gradient-accent absolute -inset-4 rounded-3xl opacity-5 blur-3xl" />
                  <div className="relative grid grid-cols-2 gap-4">
                    {[
                      {
                        icon: Shield,
                        title: "Bank-Grade Security",
                        color: "bg-blue-500/10 text-blue-500",
                      },
                      {
                        icon: Globe,
                        title: "150+ Countries",
                        color: "bg-emerald-500/10 text-emerald-500",
                      },
                      {
                        icon: Zap,
                        title: "Instant Transfers",
                        color: "bg-yellow-500/10 text-yellow-500",
                      },
                      { icon: Heart, title: "People First", color: "bg-pink-500/10 text-pink-500" },
                    ].map(({ icon: Icon, title, color }, i) => (
                      <motion.div
                        key={title}
                        variants={scaleIn}
                        custom={i}
                        className="rounded-2xl border border-border bg-card p-6 text-center transition-all duration-300 hover:-translate-y-1 hover:shadow-lifted"
                      >
                        <div
                          className={`h-12 w-12 rounded-xl ${color} mx-auto mb-3 flex items-center justify-center`}
                        >
                          <Icon className="h-6 w-6" />
                        </div>
                        <p className="text-sm font-semibold text-foreground">{title}</p>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>
        {/* ── TIMELINE ── */}
        <section className="bg-secondary/40 py-24">
          <div className="container mx-auto px-4">
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={viewport}
              className="mb-16 text-center"
            >
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3 py-1.5">
                <Clock className="h-3 w-3 text-primary" />
                <span className="text-xs font-semibold uppercase tracking-wide text-primary">
                  Our Journey
                </span>
              </div>
              <h2 className="mb-4 font-display text-4xl font-bold text-foreground">
                A history of innovation
              </h2>
              <p className="mx-auto max-w-xl text-muted-foreground">
                From two engineers with a vision to a global financial platform trusted by millions.
              </p>
            </motion.div>
            <div className="relative mx-auto max-w-3xl">
              {/* Center line */}
              <div className="absolute bottom-0 left-1/2 top-0 hidden w-0.5 -translate-x-px bg-border md:block" />
              <motion.div
                variants={stagger}
                initial="hidden"
                whileInView="visible"
                viewport={viewport}
                className="space-y-8"
              >
                {timeline.map(({ year, title, desc }, i) => (
                  <motion.div
                    key={year}
                    variants={i % 2 === 0 ? fadeLeft : fadeRight}
                    custom={i}
                    className={`relative flex items-center gap-6 md:gap-0 ${i % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"}`}
                  >
                    {/* Content */}
                    <div
                      className={`flex-1 ${i % 2 === 0 ? "md:pr-12 md:text-right" : "md:pl-12"}`}
                    >
                      <div
                        className={`rounded-2xl border border-border bg-card p-5 shadow-card transition-all duration-300 hover:shadow-lifted ${i % 2 === 0 ? "md:ml-auto" : ""} max-w-xs`}
                      >
                        <span className="text-xs font-bold uppercase tracking-wider text-accent">
                          {year}
                        </span>
                        <h3 className="mb-2 mt-1 font-display font-bold text-foreground">
                          {title}
                        </h3>
                        <p className="text-sm text-muted-foreground">{desc}</p>
                      </div>
                    </div>
                    {/* Dot */}
                    <div className="gradient-accent absolute left-1/2 z-10 hidden h-10 w-10 shrink-0 -translate-x-1/2 items-center justify-center rounded-full shadow-glow md:flex">
                      <CheckCircle className="h-5 w-5 text-accent-foreground" />
                    </div>
                    <div className="hidden flex-1 md:block" />
                  </motion.div>
                ))}
              </motion.div>
            </div>
          </div>
        </section>
        {/* ── VALUES ── */}
        <section className="bg-background py-24">
          <div className="container mx-auto px-4">
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={viewport}
              className="mb-16 text-center"
            >
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-accent/20 bg-accent/10 px-3 py-1.5">
                <Heart className="h-3 w-3 text-accent" />
                <span className="text-xs font-semibold uppercase tracking-wide text-accent">
                  Core Values
                </span>
              </div>
              <h2 className="mb-4 font-display text-4xl font-bold text-foreground">
                What we stand for
              </h2>
              <p className="mx-auto max-w-xl text-muted-foreground">
                These principles guide every decision we make.
              </p>
            </motion.div>
            <motion.div
              variants={stagger}
              initial="hidden"
              whileInView="visible"
              viewport={viewport}
              className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3"
            >
              {values.map(({ icon: Icon, title, desc }, i) => (
                <motion.div
                  key={title}
                  variants={scaleUp}
                  custom={i}
                  className="group rounded-2xl border border-border bg-card p-6 text-center transition-all duration-300 hover:border-accent/40 hover:shadow-lifted"
                >
                  <div className="gradient-accent mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl shadow-glow transition-transform duration-300 group-hover:scale-110">
                    <Icon className="h-7 w-7 text-accent-foreground" />
                  </div>
                  <h3 className="mb-2 font-display font-bold text-foreground">{title}</h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">{desc}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>
        {/* ── TEAM ── */}
        <section className="bg-secondary/40 py-24">
          <div className="container mx-auto px-4">
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={viewport}
              className="mb-16 text-center"
            >
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3 py-1.5">
                <Users className="h-3 w-3 text-primary" />
                <span className="text-xs font-semibold uppercase tracking-wide text-primary">
                  The Team
                </span>
              </div>
              <h2 className="mb-4 font-display text-4xl font-bold text-foreground">
                Meet the people behind SecureWallet
              </h2>
              <p className="mx-auto max-w-xl text-muted-foreground">
                A team of fintech veterans, security experts, and design innovators.
              </p>
            </motion.div>
            <motion.div
              variants={stagger}
              initial="hidden"
              whileInView="visible"
              viewport={viewport}
              className="mx-auto grid max-w-5xl grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3"
            >
              {team.map(({ name, role, avatar, bio, color }, i) => (
                <motion.div
                  key={name}
                  variants={fadeUp}
                  custom={i}
                  className="group rounded-2xl border border-border bg-card p-6 text-center transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lifted"
                >
                  <div
                    className={`h-20 w-20 rounded-2xl bg-gradient-to-br ${color} mx-auto mb-4 flex items-center justify-center text-2xl font-bold text-white shadow-navy transition-transform duration-300 group-hover:scale-105`}
                  >
                    {avatar}
                  </div>
                  <h3 className="font-display font-bold text-foreground">{name}</h3>
                  <p className="mb-3 mt-0.5 text-xs font-semibold text-accent">{role}</p>
                  <p className="text-xs leading-relaxed text-muted-foreground">{bio}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>
        {/* ── TESTIMONIALS ── */}
        <section className="bg-background py-24">
          <div className="container mx-auto px-4">
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={viewport}
              className="mb-16 text-center"
            >
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-warning/20 bg-warning/10 px-3 py-1.5">
                <Star className="h-3 w-3 fill-warning text-warning" />
                <span className="text-xs font-semibold uppercase tracking-wide text-warning">
                  Testimonials
                </span>
              </div>
              <h2 className="mb-4 font-display text-4xl font-bold text-foreground">
                Loved by businesses worldwide
              </h2>
            </motion.div>
            <motion.div
              variants={stagger}
              initial="hidden"
              whileInView="visible"
              viewport={viewport}
              className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-3"
            >
              {testimonials.map(({ name, role, avatar, text, stars }, i) => (
                <motion.div
                  key={name}
                  variants={scaleUp}
                  custom={i}
                  className="relative rounded-2xl border border-border bg-card p-6 transition-all duration-300 hover:shadow-lifted"
                >
                  <Quote className="absolute right-4 top-4 h-8 w-8 text-accent/20" />
                  <div className="mb-4 flex gap-1">
                    {Array.from({ length: stars }).map((_, j) => (
                      <Star key={j} className="h-4 w-4 fill-warning text-warning" />
                    ))}
                  </div>
                  <p className="mb-5 text-sm italic leading-relaxed text-muted-foreground">
                    "{text}"
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="gradient-card flex h-10 w-10 items-center justify-center rounded-full text-xs font-bold text-primary-foreground">
                      {avatar}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-foreground">{name}</p>
                      <p className="text-xs text-muted-foreground">{role}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>
        {/* ── CTA ── */}
        <section className="gradient-hero relative overflow-hidden py-24">
          <div className="pointer-events-none absolute inset-0">
            <div
              className="absolute left-1/2 top-1/2 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/2 animate-pulse-glow rounded-full opacity-[0.08]"
              style={{ background: "radial-gradient(circle, hsl(162 90% 44%), transparent)" }}
            />
          </div>
          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="visible"
            viewport={viewport}
            className="container relative z-10 mx-auto max-w-2xl px-4 text-center"
          >
            <motion.div variants={scaleIn} custom={0}>
              <Award className="mx-auto mb-5 h-14 w-14 text-accent drop-shadow-[0_0_16px_hsl(162_90%_44%/0.8)]" />
            </motion.div>
            <motion.h2
              variants={fadeUp}
              custom={1}
              className="mb-4 font-display text-4xl font-bold text-primary-foreground md:text-5xl"
            >
              Ready to join us?
            </motion.h2>
            <motion.p
              variants={fadeUp}
              custom={2}
              className="mb-8 text-lg text-primary-foreground/70"
            >
              Join 2.4M+ users managing their money smarter with SecureWallet.
            </motion.p>
            <motion.div variants={fadeUp} custom={3}>
              <Button variant="accent" size="xl" asChild className="group shadow-glow">
                <Link to="/register">
                  Get Started Free{" "}
                  <ArrowRight className="ml-1 h-5 w-5 transition-transform group-hover:translate-x-1" />
                </Link>
              </Button>
            </motion.div>
          </motion.div>
        </section>
      </main>
      <PublicFooter />
    </div>
  );
}
export { AboutPage as default };
