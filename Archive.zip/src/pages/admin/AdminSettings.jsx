import { useState } from "react";
import {
  Settings,
  Globe,
  Mail,
  Shield,
  CreditCard,
  Save,
  Bell,
  AlertCircle,
  Key,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import { fadeUp, fadeDown, stagger } from "@/lib/motion";
import { useToast } from "@/hooks/use-toast";
const tabs = [
  { id: "general", icon: Settings, label: "General" },
  { id: "security", icon: Shield, label: "Security Rules" },
  { id: "payment", icon: CreditCard, label: "Payment Gateways" },
  { id: "email", icon: Mail, label: "Email Templates" },
  { id: "notif", icon: Bell, label: "Notifications" },
];
function AdminSettings() {
  const [activeTab, setActiveTab] = useState("general");
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [general, setGeneral] = useState({
    platformName: "SecureWallet",
    supportEmail: "support@securewallet.io",
    website: "https://securewallet.io",
    defaultCurrency: "USD",
    maintenanceMode: false,
    registrationEnabled: true,
    kycRequired: true,
    maxTransferLimit: "50000",
    minTransferAmount: "1",
  });
  const [security, setSecurity] = useState({
    twoFactorRequired: false,
    maxLoginAttempts: "5",
    sessionTimeout: "30",
    ipWhitelisting: false,
    fraudDetection: true,
    velocityChecks: true,
    maxDailyWithdrawals: "10",
    riskScoring: true,
  });
  const [gateways, setGateways] = useState({
    stripeEnabled: true,
    paypalEnabled: true,
    bankTransferEnabled: true,
    cryptoEnabled: false,
    stripeKey:
      "sk_live_\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022xxxx",
    paypalClientId:
      "AXXx\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022xxxx",
    processingFee: "0.5",
    instantWithdrawalFee: "1.5",
  });
  const [notifs, setNotifs] = useState({
    emailOnLogin: true,
    emailOnTransaction: true,
    emailOnKyc: true,
    smsOnTransaction: false,
    smsOnLogin: false,
    pushEnabled: true,
    weeklyReport: true,
  });
  const handleSave = async () => {
    setSaving(true);
    await new Promise((r) => setTimeout(r, 1200));
    setSaving(false);
    toast({ title: "Settings saved", description: "Your changes have been applied successfully." });
  };
  const SwitchRow = ({ label, desc, checked, onChange }) => (
    <div className="flex items-center justify-between border-b border-border/50 py-3 last:border-0">
      <div>
        <p className="text-sm font-medium text-foreground">{label}</p>
        <p className="mt-0.5 text-xs text-muted-foreground">{desc}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
  const FieldRow = ({ label, value, onChange, type = "text", placeholder = "" }) => (
    <div>
      <Label className="text-xs font-medium text-foreground">{label}</Label>
      <Input
        type={type}
        className="mt-1.5 h-10"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
      />
    </div>
  );
  return (
    <motion.div variants={stagger} initial="hidden" animate="visible" className="space-y-6">
      <motion.div variants={fadeDown} custom={0} className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">System Settings</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Global platform configuration and management
          </p>
        </div>
        <Button
          variant="accent"
          className="gap-2 shadow-glow"
          onClick={handleSave}
          disabled={saving}
        >
          {saving ? (
            <>
              <RefreshCw className="h-4 w-4 animate-spin" />
              Saving…
            </>
          ) : (
            <>
              <Save className="h-4 w-4" />
              Save Changes
            </>
          )}
        </Button>
      </motion.div>
      <div className="flex flex-col gap-6 lg:flex-row">
        {/* Sidebar Tabs */}
        <motion.div variants={fadeUp} custom={1} className="shrink-0 space-y-1 lg:w-52">
          {tabs.map(({ id, icon: Icon, label }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className={cn(
                "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all",
                activeTab === id
                  ? "border border-accent/20 bg-accent/10 text-accent"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground",
              )}
            >
              <Icon className="h-4 w-4 shrink-0" />
              {label}
            </button>
          ))}
        </motion.div>
        {/* Content */}
        <motion.div variants={fadeUp} custom={2} className="flex-1">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="space-y-5 rounded-2xl border border-border bg-card p-6 shadow-card"
            >
              {/* ── General ── */}
              {activeTab === "general" && (
                <>
                  <div>
                    <h3 className="mb-4 flex items-center gap-2 font-display font-semibold text-foreground">
                      <Globe className="h-4 w-4 text-accent" />
                      Platform Configuration
                    </h3>
                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <FieldRow
                        label="Platform Name"
                        value={general.platformName}
                        onChange={(v) => setGeneral((g) => ({ ...g, platformName: v }))}
                      />
                      <FieldRow
                        label="Support Email"
                        value={general.supportEmail}
                        onChange={(v) => setGeneral((g) => ({ ...g, supportEmail: v }))}
                        type="email"
                      />
                      <FieldRow
                        label="Website URL"
                        value={general.website}
                        onChange={(v) => setGeneral((g) => ({ ...g, website: v }))}
                      />
                      <FieldRow
                        label="Default Currency"
                        value={general.defaultCurrency}
                        onChange={(v) => setGeneral((g) => ({ ...g, defaultCurrency: v }))}
                      />
                      <FieldRow
                        label="Max Transfer Limit ($)"
                        value={general.maxTransferLimit}
                        onChange={(v) => setGeneral((g) => ({ ...g, maxTransferLimit: v }))}
                        type="number"
                      />
                      <FieldRow
                        label="Min Transfer Amount ($)"
                        value={general.minTransferAmount}
                        onChange={(v) => setGeneral((g) => ({ ...g, minTransferAmount: v }))}
                        type="number"
                      />
                    </div>
                  </div>
                  <div className="border-t border-border pt-2">
                    <h4 className="mb-3 text-sm font-semibold text-foreground">Platform Flags</h4>
                    <div className="space-y-1">
                      <SwitchRow
                        label="Maintenance Mode"
                        desc="Show maintenance page to all users"
                        checked={general.maintenanceMode}
                        onChange={(v) => setGeneral((g) => ({ ...g, maintenanceMode: v }))}
                      />
                      <SwitchRow
                        label="New Registrations"
                        desc="Allow new user sign-ups"
                        checked={general.registrationEnabled}
                        onChange={(v) => setGeneral((g) => ({ ...g, registrationEnabled: v }))}
                      />
                      <SwitchRow
                        label="KYC Required"
                        desc="Require identity verification for transactions"
                        checked={general.kycRequired}
                        onChange={(v) => setGeneral((g) => ({ ...g, kycRequired: v }))}
                      />
                    </div>
                  </div>
                  {general.maintenanceMode && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      className="flex items-center gap-3 rounded-xl border border-warning/30 bg-warning/10 p-4"
                    >
                      <AlertCircle className="h-4 w-4 shrink-0 text-warning" />
                      <p className="text-sm font-medium text-warning">
                        Maintenance mode is ON. Users will see a maintenance page.
                      </p>
                    </motion.div>
                  )}
                </>
              )}
              {/* ── Security Rules ── */}
              {activeTab === "security" && (
                <>
                  <h3 className="flex items-center gap-2 font-display font-semibold text-foreground">
                    <Shield className="h-4 w-4 text-accent" />
                    Security Configuration
                  </h3>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <FieldRow
                      label="Max Login Attempts"
                      value={security.maxLoginAttempts}
                      onChange={(v) => setSecurity((s) => ({ ...s, maxLoginAttempts: v }))}
                      type="number"
                    />
                    <FieldRow
                      label="Session Timeout (min)"
                      value={security.sessionTimeout}
                      onChange={(v) => setSecurity((s) => ({ ...s, sessionTimeout: v }))}
                      type="number"
                    />
                    <FieldRow
                      label="Max Daily Withdrawals"
                      value={security.maxDailyWithdrawals}
                      onChange={(v) => setSecurity((s) => ({ ...s, maxDailyWithdrawals: v }))}
                      type="number"
                    />
                  </div>
                  <div className="space-y-1 border-t border-border pt-2">
                    <SwitchRow
                      label="Require 2FA for All Users"
                      desc="Force two-factor authentication platform-wide"
                      checked={security.twoFactorRequired}
                      onChange={(v) => setSecurity((s) => ({ ...s, twoFactorRequired: v }))}
                    />
                    <SwitchRow
                      label="IP Whitelisting"
                      desc="Only allow logins from whitelisted IPs"
                      checked={security.ipWhitelisting}
                      onChange={(v) => setSecurity((s) => ({ ...s, ipWhitelisting: v }))}
                    />
                    <SwitchRow
                      label="Fraud Detection AI"
                      desc="Automatically flag suspicious transactions"
                      checked={security.fraudDetection}
                      onChange={(v) => setSecurity((s) => ({ ...s, fraudDetection: v }))}
                    />
                    <SwitchRow
                      label="Velocity Checks"
                      desc="Limit rapid repeat transactions"
                      checked={security.velocityChecks}
                      onChange={(v) => setSecurity((s) => ({ ...s, velocityChecks: v }))}
                    />
                    <SwitchRow
                      label="Risk Scoring"
                      desc="Assign risk scores to all transactions"
                      checked={security.riskScoring}
                      onChange={(v) => setSecurity((s) => ({ ...s, riskScoring: v }))}
                    />
                  </div>
                </>
              )}
              {/* ── Payment Gateways ── */}
              {activeTab === "payment" && (
                <>
                  <h3 className="flex items-center gap-2 font-display font-semibold text-foreground">
                    <CreditCard className="h-4 w-4 text-accent" />
                    Payment Gateway Configuration
                  </h3>
                  <div className="space-y-4">
                    {[
                      {
                        label: "Stripe",
                        key: "stripeEnabled",
                        apiLabel: "Stripe Secret Key",
                        apiKey: "stripeKey",
                      },
                      {
                        label: "PayPal",
                        key: "paypalEnabled",
                        apiLabel: "PayPal Client ID",
                        apiKey: "paypalClientId",
                      },
                    ].map(({ label, key, apiLabel, apiKey }) => (
                      <div
                        key={label}
                        className={cn(
                          "rounded-xl border p-4 transition-all",
                          gateways[key] ? "border-accent/30 bg-accent/5" : "border-border",
                        )}
                      >
                        <div className="mb-3 flex items-center justify-between">
                          <p className="text-sm font-semibold text-foreground">{label}</p>
                          <Switch
                            checked={gateways[key]}
                            onCheckedChange={(v) => setGateways((g) => ({ ...g, [key]: v }))}
                          />
                        </div>
                        {gateways[key] && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                          >
                            <Label className="text-xs font-medium text-foreground">
                              {apiLabel}
                            </Label>
                            <div className="relative mt-1.5">
                              <Key className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                              <Input
                                type="password"
                                className="h-10 pl-9 font-mono text-xs"
                                value={gateways[apiKey]}
                                onChange={(e) =>
                                  setGateways((g) => ({ ...g, [apiKey]: e.target.value }))
                                }
                              />
                            </div>
                          </motion.div>
                        )}
                      </div>
                    ))}
                  </div>
                  <div className="space-y-1 border-t border-border pt-2">
                    <SwitchRow
                      label="Bank Transfer"
                      desc="Allow direct bank transfers"
                      checked={gateways.bankTransferEnabled}
                      onChange={(v) => setGateways((g) => ({ ...g, bankTransferEnabled: v }))}
                    />
                    <SwitchRow
                      label="Cryptocurrency"
                      desc="Accept crypto payments (beta)"
                      checked={gateways.cryptoEnabled}
                      onChange={(v) => setGateways((g) => ({ ...g, cryptoEnabled: v }))}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <FieldRow
                      label="Standard Processing Fee (%)"
                      value={gateways.processingFee}
                      onChange={(v) => setGateways((g) => ({ ...g, processingFee: v }))}
                      type="number"
                    />
                    <FieldRow
                      label="Instant Withdrawal Fee (%)"
                      value={gateways.instantWithdrawalFee}
                      onChange={(v) => setGateways((g) => ({ ...g, instantWithdrawalFee: v }))}
                      type="number"
                    />
                  </div>
                </>
              )}
              {/* ── Email Templates ── */}
              {activeTab === "email" && (
                <>
                  <h3 className="flex items-center gap-2 font-display font-semibold text-foreground">
                    <Mail className="h-4 w-4 text-accent" />
                    Email Template Configuration
                  </h3>
                  {[
                    {
                      label: "Welcome Email",
                      subject: "Welcome to SecureWallet!",
                      desc: "Sent when a new user registers",
                    },
                    {
                      label: "OTP Verification",
                      subject: "Your SecureWallet verification code",
                      desc: "Sent for 2FA and phone verification",
                    },
                    {
                      label: "Transaction Receipt",
                      subject: "Transaction confirmed \u2013 SecureWallet",
                      desc: "Sent after each successful transaction",
                    },
                    {
                      label: "KYC Approved",
                      subject: "Your identity has been verified!",
                      desc: "Sent when KYC is approved by admin",
                    },
                    {
                      label: "KYC Rejected",
                      subject: "KYC verification needs attention",
                      desc: "Sent when KYC is rejected with reason",
                    },
                    {
                      label: "Password Reset",
                      subject: "Reset your SecureWallet password",
                      desc: "Sent when password reset is requested",
                    },
                  ].map(({ label, subject, desc }, i) => (
                    <motion.div
                      key={label}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.06 }}
                      className="rounded-xl border border-border p-4 transition-all hover:border-accent/30"
                    >
                      <div className="mb-2 flex items-center justify-between">
                        <p className="text-sm font-semibold text-foreground">{label}</p>
                        <Button variant="outline" size="sm" className="h-7 px-3 text-xs">
                          Edit
                        </Button>
                      </div>
                      <p className="mb-1 font-mono text-xs text-accent">{subject}</p>
                      <p className="text-xs text-muted-foreground">{desc}</p>
                    </motion.div>
                  ))}
                </>
              )}
              {/* ── Notifications ── */}
              {activeTab === "notif" && (
                <>
                  <h3 className="flex items-center gap-2 font-display font-semibold text-foreground">
                    <Bell className="h-4 w-4 text-accent" />
                    Notification Settings
                  </h3>
                  <div>
                    <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                      Email Notifications
                    </p>
                    <div className="space-y-1">
                      <SwitchRow
                        label="Login Alert Email"
                        desc="Email users when their account is logged into"
                        checked={notifs.emailOnLogin}
                        onChange={(v) => setNotifs((n) => ({ ...n, emailOnLogin: v }))}
                      />
                      <SwitchRow
                        label="Transaction Email"
                        desc="Email receipt after each transaction"
                        checked={notifs.emailOnTransaction}
                        onChange={(v) => setNotifs((n) => ({ ...n, emailOnTransaction: v }))}
                      />
                      <SwitchRow
                        label="KYC Status Email"
                        desc="Email when KYC status changes"
                        checked={notifs.emailOnKyc}
                        onChange={(v) => setNotifs((n) => ({ ...n, emailOnKyc: v }))}
                      />
                      <SwitchRow
                        label="Weekly Summary"
                        desc="Send weekly activity report emails"
                        checked={notifs.weeklyReport}
                        onChange={(v) => setNotifs((n) => ({ ...n, weeklyReport: v }))}
                      />
                    </div>
                  </div>
                  <div className="border-t border-border pt-2">
                    <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                      SMS Notifications
                    </p>
                    <div className="space-y-1">
                      <SwitchRow
                        label="SMS on Login"
                        desc="Send SMS alert on account login"
                        checked={notifs.smsOnLogin}
                        onChange={(v) => setNotifs((n) => ({ ...n, smsOnLogin: v }))}
                      />
                      <SwitchRow
                        label="SMS on Transaction"
                        desc="Send SMS for every transaction"
                        checked={notifs.smsOnTransaction}
                        onChange={(v) => setNotifs((n) => ({ ...n, smsOnTransaction: v }))}
                      />
                    </div>
                  </div>
                  <div className="border-t border-border pt-2">
                    <SwitchRow
                      label="Push Notifications"
                      desc="Enable browser/app push notifications"
                      checked={notifs.pushEnabled}
                      onChange={(v) => setNotifs((n) => ({ ...n, pushEnabled: v }))}
                    />
                  </div>
                </>
              )}
            </motion.div>
          </AnimatePresence>
        </motion.div>
      </div>
    </motion.div>
  );
}
export { AdminSettings as default };
