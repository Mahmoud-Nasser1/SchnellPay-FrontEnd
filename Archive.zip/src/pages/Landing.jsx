import { Link } from "react-router-dom";
import {
  Shield,
  Zap,
  Globe,
  Lock,
  ArrowRight,
  Star,
  CheckCircle,
  TrendingUp,
  Send,
  CreditCard,
  Smartphone,
  Users,
  Award,
  ChevronDown,
  Play,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import PublicNav from "@/components/PublicNav";
import PublicFooter from "@/components/PublicFooter";
import heroDashboard from "@/assets/hero-dashboard.jpg";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { motion } from "framer-motion";
import { fadeUp, fadeDown, slideLeft, slideRight, scaleIn, stagger } from "@/lib/motion";
const features = [
  {
    icon: Zap,
    title: "Instant Transfers",
    desc: "Send money globally in seconds with near-zero fees.",
  },
  {
    icon: Shield,
    title: "Bank-Grade Security",
    desc: "256-bit encryption, biometric auth, and real-time fraud detection.",
  },
  {
    icon: Globe,
    title: "150+ Countries",
    desc: "Accept and send payments in 50+ currencies worldwide.",
  },
  {
    icon: TrendingUp,
    title: "Smart Analytics",
    desc: "Visualize your spending and earning patterns with AI insights.",
  },
  {
    icon: CreditCard,
    title: "Virtual Cards",
    desc: "Generate unlimited virtual cards for secure online shopping.",
  },
  {
    icon: Lock,
    title: "2FA & Biometrics",
    desc: "Multiple layers of authentication keep your funds safe.",
  },
];
const testimonials = [
  {
    name: "Sarah Johnson",
    role: "E-commerce Owner",
    avatar: "SJ",
    text: "SecureWallet transformed how I manage business finances. The instant transfers and analytics are incredible.",
    stars: 5,
  },
  {
    name: "Marcus Chen",
    role: "Freelance Developer",
    avatar: "MC",
    text: "I receive payments from 12 countries. SecureWallet makes currency conversion seamless and affordable.",
    stars: 5,
  },
  {
    name: "Priya Sharma",
    role: "Digital Nomad",
    avatar: "PS",
    text: "The security features give me peace of mind while traveling. The biometric lock is a game changer.",
    stars: 5,
  },
];
const stats = [
  { label: "Active Users", value: "2.4M+" },
  { label: "Transactions Daily", value: "$180M+" },
  { label: "Countries", value: "150+" },
  { label: "Uptime SLA", value: "99.99%" },
];
const faqs = [
  {
    q: "Is SecureWallet free to use?",
    a: "Yes! Creating an account and basic transfers are completely free. We only charge small fees on currency conversions and instant withdrawals.",
  },
  {
    q: "How secure is my money?",
    a: "Your funds are protected by 256-bit encryption, 2FA, biometric authentication, and real-time fraud detection AI. We are PCI DSS Level 1 certified.",
  },
  {
    q: "How fast are transfers?",
    a: "Internal transfers are instant. Bank withdrawals typically take 1\u20132 business days depending on your bank.",
  },
  {
    q: "What countries are supported?",
    a: "We support users in 150+ countries with full KYC verification. Currency exchange is available for 50+ currencies.",
  },
];
function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground">
      <PublicNav />
      {/* ── HERO ── */}
      <section className="gradient-hero relative flex min-h-screen items-center overflow-hidden">
        {/* Background decorations */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute right-10 top-20 h-[520px] w-[520px] animate-pulse-glow rounded-full opacity-[0.13]"
            style={{ background: "radial-gradient(circle, hsl(162 100% 44%), transparent)" }}
          />
          <div
            className="absolute -bottom-24 left-0 h-80 w-80 rounded-full opacity-[0.07]"
            style={{ background: "radial-gradient(circle, hsl(213 85% 50%), transparent)" }}
          />
          <div
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage:
                "linear-gradient(hsl(0 0% 100%) 1px, transparent 1px), linear-gradient(90deg, hsl(0 0% 100%) 1px, transparent 1px)",
              backgroundSize: "40px 40px",
            }}
          />
          {[
            { top: "15%", left: "8%", delay: "0s" },
            { top: "60%", left: "3%", delay: "1s" },
            { top: "30%", right: "5%", delay: "0.5s" },
            { top: "75%", right: "12%", delay: "1.5s" },
          ].map((pos, i) => (
            <div
              key={i}
              className="absolute h-2 w-2 animate-float rounded-full bg-accent/40"
              style={{ ...pos, animationDelay: pos.delay }}
            />
          ))}
        </div>
        <div className="container relative z-10 mx-auto px-4 pb-16 pt-28">
          <div className="grid items-center gap-14 lg:grid-cols-2">
            {/* Left: text */}
            <motion.div variants={stagger} initial="hidden" animate="visible" className="space-y-6">
              <motion.div
                variants={fadeDown}
                custom={0}
                className="inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/10 px-4 py-2"
              >
                <Sparkles className="h-3.5 w-3.5 text-accent" />
                <span className="text-xs font-semibold uppercase tracking-wide text-accent">
                  Trusted by 2.4M+ users worldwide
                </span>
              </motion.div>
              <motion.h1
                variants={fadeUp}
                custom={1}
                className="font-display text-5xl font-bold leading-[1.05] text-primary-foreground md:text-6xl lg:text-7xl"
              >
                The Future of <span className="text-gradient-accent">Digital Finance</span> is Here
              </motion.h1>
              <motion.p
                variants={fadeUp}
                custom={2}
                className="max-w-xl text-lg leading-relaxed text-primary-foreground/75"
              >
                Send, receive, and manage money globally with enterprise-grade security. One wallet.
                Every currency. Zero hassle.
              </motion.p>
              <motion.div variants={fadeUp} custom={3} className="flex flex-col gap-4 sm:flex-row">
                <Button variant="accent" size="xl" asChild className="group shadow-glow">
                  <Link to="/register">
                    Open Free Account
                    <ArrowRight className="ml-1 h-5 w-5 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
                <Button
                  variant="ghost"
                  size="xl"
                  className="border border-primary-foreground/25 text-primary-foreground/85 hover:bg-primary-foreground/10 hover:text-primary-foreground"
                >
                  <Play className="mr-2 h-4 w-4 fill-current" />
                  Watch Demo
                </Button>
              </motion.div>
              <motion.div
                variants={fadeUp}
                custom={4}
                className="flex flex-wrap items-center gap-3"
              >
                {["PCI DSS Compliant", "SOC 2 Certified", "256-bit SSL"].map((badge) => (
                  <div key={badge} className="secure-badge">
                    <Shield className="h-3 w-3" />
                    {badge}
                  </div>
                ))}
              </motion.div>
            </motion.div>
            {/* Right: hero image */}
            <motion.div
              variants={slideRight}
              initial="hidden"
              animate="visible"
              custom={0}
              className="relative hidden lg:block"
            >
              <div className="gradient-accent absolute -inset-6 rounded-3xl opacity-20 blur-3xl" />
              <div className="relative animate-float">
                <div className="gradient-accent absolute -inset-1 rounded-2xl opacity-25 blur-xl" />
                <div className="relative overflow-hidden rounded-2xl border border-primary-foreground/10 shadow-navy">
                  <img
                    src={heroDashboard}
                    alt="SecureWallet Dashboard Preview"
                    className="h-auto w-full object-cover"
                    loading="eager"
                  />
                  <div className="absolute right-4 top-4 flex items-center gap-1.5 rounded-full bg-accent/90 px-3 py-1.5 backdrop-blur-sm">
                    <span className="h-2 w-2 animate-pulse rounded-full bg-accent-foreground" />
                    <span className="text-xs font-bold text-accent-foreground">LIVE</span>
                  </div>
                  <div className="glass absolute bottom-4 left-4 right-4 rounded-xl border border-primary-foreground/10 p-4">
                    <p className="mb-0.5 text-xs text-primary-foreground/65">Total Balance</p>
                    <p className="font-display text-2xl font-bold text-primary-foreground">
                      $48,250.00
                    </p>
                    <div className="mt-1 flex items-center gap-1">
                      <TrendingUp className="h-3 w-3 text-accent" />
                      <span className="text-xs font-medium text-accent">+12.4% this month</span>
                    </div>
                  </div>
                </div>
              </div>
              {/* Floating stat chips */}
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                className="glass absolute -left-10 top-1/3 animate-float rounded-xl border border-primary-foreground/10 p-3 shadow-navy"
                style={{ animationDelay: "0.5s" }}
              >
                <div className="flex items-center gap-2">
                  <div className="gradient-accent flex h-8 w-8 items-center justify-center rounded-lg">
                    <Send className="h-4 w-4 text-accent-foreground" />
                  </div>
                  <div>
                    <p className="text-[10px] text-primary-foreground/55">Sent today</p>
                    <p className="text-sm font-bold text-primary-foreground">$1,240</p>
                  </div>
                </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.9, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                className="glass absolute -right-8 top-1/4 animate-float rounded-xl border border-primary-foreground/10 p-3 shadow-navy"
                style={{ animationDelay: "1s" }}
              >
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-success/20">
                    <CheckCircle className="h-4 w-4 text-success" />
                  </div>
                  <div>
                    <p className="text-[10px] text-primary-foreground/55">Transaction</p>
                    <p className="text-xs font-bold text-success">Verified ✓</p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <ChevronDown className="h-6 w-6 text-primary-foreground/40" />
        </div>
      </section>
      {/* ── STATS ── */}
      <section className="border-y border-primary-foreground/10 bg-primary py-16">
        <div className="container mx-auto px-4">
          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            className="grid grid-cols-2 gap-8 md:grid-cols-4"
          >
            {stats.map((stat, i) => (
              <motion.div key={stat.label} variants={fadeUp} custom={i} className="text-center">
                <p className="mb-1 font-display text-3xl font-bold text-accent md:text-4xl">
                  {stat.value}
                </p>
                <p className="text-sm text-primary-foreground/65">{stat.label}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
      {/* ── FEATURES ── */}
      <section id="features" className="bg-background py-24">
        <div className="container mx-auto px-4">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            className="mb-16 text-center"
          >
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-accent/20 bg-accent/10 px-3 py-1.5">
              <Zap className="h-3 w-3 text-accent" />
              <span className="text-xs font-semibold uppercase tracking-wide text-accent">
                Powerful Features
              </span>
            </div>
            <h2 className="mb-4 font-display text-4xl font-bold text-foreground md:text-5xl">
              Everything you need to manage money
            </h2>
            <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
              From instant global transfers to advanced analytics, SecureWallet is built for the
              modern economy.
            </p>
          </motion.div>
          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3"
          >
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                variants={fadeUp}
                custom={i}
                className="group rounded-2xl border border-border bg-card p-6 transition-all duration-300 hover:border-accent/40 hover:shadow-lifted"
              >
                <div className="gradient-accent mb-4 flex h-12 w-12 items-center justify-center rounded-xl shadow-glow transition-transform duration-300 group-hover:scale-110">
                  <feature.icon className="h-6 w-6 text-accent-foreground" />
                </div>
                <h3 className="mb-2 font-display text-lg font-semibold text-foreground">
                  {feature.title}
                </h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{feature.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
      {/* ── SECURITY ── */}
      <section id="security" className="bg-secondary/40 py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 items-center gap-16 lg:grid-cols-2">
            <motion.div
              variants={slideLeft}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-80px" }}
            >
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-success/20 bg-success/10 px-3 py-1.5">
                <Shield className="h-3 w-3 text-success" />
                <span className="text-xs font-semibold uppercase tracking-wide text-success">
                  Security First
                </span>
              </div>
              <h2 className="mb-4 font-display text-4xl font-bold text-foreground">
                Your money is protected by{" "}
                <span className="text-gradient-accent">military-grade security</span>
              </h2>
              <p className="mb-8 leading-relaxed text-muted-foreground">
                We combine the latest cryptographic standards with AI-powered fraud detection to
                ensure your funds are always safe.
              </p>
              <ul className="space-y-4">
                {[
                  "256-bit AES end-to-end encryption",
                  "Real-time AI fraud detection & alerts",
                  "Biometric & two-factor authentication",
                  "Zero-knowledge architecture",
                  "Regular third-party security audits",
                ].map((item, i) => (
                  <motion.li
                    key={item}
                    variants={fadeUp}
                    custom={i}
                    className="flex items-center gap-3 text-sm text-foreground/85"
                  >
                    <div className="gradient-accent flex h-5 w-5 shrink-0 items-center justify-center rounded-full">
                      <CheckCircle className="h-3 w-3 text-accent-foreground" />
                    </div>
                    {item}
                  </motion.li>
                ))}
              </ul>
            </motion.div>
            <motion.div
              variants={slideRight}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-80px" }}
              className="relative"
            >
              <div className="gradient-accent absolute inset-0 rounded-3xl opacity-5 blur-3xl" />
              <div className="grid grid-cols-2 gap-4">
                {[
                  {
                    icon: Shield,
                    title: "Encrypted",
                    desc: "All data encrypted in transit & at rest",
                  },
                  { icon: Lock, title: "2FA", desc: "Multi-factor authentication required" },
                  { icon: Smartphone, title: "Biometric", desc: "Fingerprint & face recognition" },
                  { icon: Award, title: "Certified", desc: "PCI DSS Level 1 & SOC 2 Type II" },
                ].map(({ icon: Icon, title, desc }, i) => (
                  <motion.div
                    key={title}
                    variants={scaleIn}
                    custom={i}
                    className="glass-card hover:glow-accent rounded-2xl p-5 transition-all duration-300 hover:-translate-y-1"
                  >
                    <div className="gradient-accent mb-3 flex h-10 w-10 items-center justify-center rounded-lg">
                      <Icon className="h-5 w-5 text-accent-foreground" />
                    </div>
                    <h4 className="mb-1 text-sm font-semibold text-foreground">{title}</h4>
                    <p className="text-xs text-muted-foreground">{desc}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      {/* ── TESTIMONIALS ── */}
      <section className="bg-background py-24">
        <div className="container mx-auto px-4">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            className="mb-16 text-center"
          >
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-warning/20 bg-warning/10 px-3 py-1.5">
              <Star className="h-3 w-3 fill-warning text-warning" />
              <span className="text-xs font-semibold uppercase tracking-wide text-warning">
                Customer Reviews
              </span>
            </div>
            <h2 className="mb-4 font-display text-4xl font-bold text-foreground">
              Loved by users worldwide
            </h2>
            <p className="text-muted-foreground">See what people are saying about SecureWallet</p>
          </motion.div>
          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            className="grid grid-cols-1 gap-6 md:grid-cols-3"
          >
            {testimonials.map((t, i) => (
              <motion.div
                key={t.name}
                variants={fadeUp}
                custom={i}
                className="rounded-2xl border border-border bg-card p-6 shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-lifted"
              >
                <div className="mb-4 flex gap-1">
                  {Array.from({ length: t.stars }).map((_, j) => (
                    <Star key={j} className="h-4 w-4 fill-warning text-warning" />
                  ))}
                </div>
                <p className="mb-5 text-sm italic leading-relaxed text-foreground/80">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="gradient-card flex h-10 w-10 items-center justify-center rounded-full text-xs font-bold text-primary-foreground">
                    {t.avatar}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{t.name}</p>
                    <p className="text-xs text-muted-foreground">{t.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
      {/* ── HOW IT WORKS ── */}
      <section className="bg-secondary/40 py-24">
        <div className="container mx-auto px-4">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            className="mb-16 text-center"
          >
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3 py-1.5">
              <Users className="h-3 w-3 text-primary dark:text-primary-foreground" />
              <span className="text-xs font-semibold uppercase tracking-wide text-primary dark:text-primary-foreground/80">
                How It Works
              </span>
            </div>
            <h2 className="mb-4 font-display text-4xl font-bold text-foreground">
              Get started in 3 simple steps
            </h2>
            <p className="mx-auto max-w-2xl text-muted-foreground">
              Your secure digital wallet is just minutes away.
            </p>
          </motion.div>
          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            className="relative grid grid-cols-1 gap-8 md:grid-cols-3"
          >
            {[
              {
                step: "01",
                title: "Create Account",
                desc: "Sign up in under 2 minutes with your email or social account.",
                icon: Users,
              },
              {
                step: "02",
                title: "Verify Identity",
                desc: "Quick KYC verification to keep your account and funds secure.",
                icon: Shield,
              },
              {
                step: "03",
                title: "Start Transacting",
                desc: "Send, receive, and manage money globally with zero friction.",
                icon: Zap,
              },
            ].map(({ step, title, desc, icon: Icon }, i) => (
              <motion.div key={step} variants={fadeUp} custom={i} className="relative text-center">
                <div className="gradient-accent mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl shadow-glow">
                  <Icon className="h-8 w-8 text-accent-foreground" />
                </div>
                <div className="absolute left-1/2 top-3 -translate-x-1/2 -translate-y-full select-none font-display text-6xl font-bold text-foreground/5">
                  {step}
                </div>
                <h3 className="mb-2 font-display text-xl font-bold text-foreground">{title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
      {/* ── FAQ ── */}
      <section id="faq" className="bg-background py-24">
        <div className="container mx-auto max-w-3xl px-4">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            className="mb-16 text-center"
          >
            <h2 className="mb-4 font-display text-4xl font-bold text-foreground">
              Frequently Asked Questions
            </h2>
            <p className="text-muted-foreground">Everything you need to know about SecureWallet</p>
          </motion.div>
          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
          >
            <Accordion type="single" collapsible className="space-y-3">
              {faqs.map((faq, i) => (
                <motion.div key={faq.q} variants={fadeUp} custom={i}>
                  <AccordionItem
                    value={`faq-${i}`}
                    className="overflow-hidden rounded-xl border border-border bg-card px-6 shadow-card"
                  >
                    <AccordionTrigger className="py-5 text-left font-medium text-foreground hover:no-underline">
                      {faq.q}
                    </AccordionTrigger>
                    <AccordionContent className="pb-5 text-sm leading-relaxed text-muted-foreground">
                      {faq.a}
                    </AccordionContent>
                  </AccordionItem>
                </motion.div>
              ))}
            </Accordion>
          </motion.div>
        </div>
      </section>
      {/* ── CTA ── */}
      <section className="gradient-hero relative overflow-hidden py-24">
        <div
          className="absolute inset-0 opacity-[0.035]"
          style={{
            backgroundImage:
              "linear-gradient(hsl(0 0% 100%) 1px, transparent 1px), linear-gradient(90deg, hsl(0 0% 100%) 1px, transparent 1px)",
            backgroundSize: "40px 40px",
          }}
        />
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          className="container relative z-10 mx-auto px-4 text-center"
        >
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/20 px-3 py-1.5">
            <Sparkles className="h-3 w-3 text-accent" />
            <span className="text-xs font-semibold uppercase tracking-wide text-accent">
              Join Millions
            </span>
          </div>
          <h2 className="mx-auto mb-6 max-w-2xl font-display text-4xl font-bold text-primary-foreground md:text-5xl">
            Ready to take control of your finances?
          </h2>
          <p className="mx-auto mb-10 max-w-xl text-lg text-primary-foreground/70">
            Open your free account today. No hidden fees. No minimums. Just seamless financial
            freedom.
          </p>
          <div className="flex flex-col justify-center gap-4 sm:flex-row">
            <Button variant="accent" size="xl" asChild className="group shadow-glow">
              <Link to="/register">
                Get Started Free
                <ArrowRight className="ml-1 h-5 w-5 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
            <Button
              variant="ghost"
              size="xl"
              className="border border-primary-foreground/25 text-primary-foreground/85 hover:bg-primary-foreground/10 hover:text-primary-foreground"
            >
              <Link to="/login">Sign In</Link>
            </Button>
          </div>
          <p className="mt-8 text-xs text-primary-foreground/40">
            By signing up you agree to our Terms & Privacy Policy.
          </p>
        </motion.div>
      </section>
      <PublicFooter />
    </div>
  );
}
export { LandingPage as default };
