import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Shield,
  Eye,
  EyeOff,
  Mail,
  Lock,
  User,
  Phone,
  ArrowRight,
  Check,
  Zap,
  Globe,
  TrendingUp,
  CreditCard,
  Star,
  ChevronDown,
  AtSign,
  KeyRound,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useTheme } from "@/hooks/use-theme";
import { Moon, Sun } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import { fadeDown, fadeUp, stagger } from "@/lib/motion";
const benefits = [
  { icon: Zap, text: "Instant global transfers" },
  { icon: Globe, text: "150+ countries supported" },
  { icon: TrendingUp, text: "Smart analytics & insights" },
  { icon: CreditCard, text: "Free virtual cards" },
];
const testimonial = {
  name: "Sarah Johnson",
  role: "E-commerce Owner",
  avatar: "SJ",
  text: "SecureWallet transformed how I manage business finances. Absolutely love it!",
  stars: 5,
};
const countries = [
  { code: "US", name: "United States", flag: "\u{1F1FA}\u{1F1F8}" },
  { code: "GB", name: "United Kingdom", flag: "\u{1F1EC}\u{1F1E7}" },
  { code: "CA", name: "Canada", flag: "\u{1F1E8}\u{1F1E6}" },
  { code: "AU", name: "Australia", flag: "\u{1F1E6}\u{1F1FA}" },
  { code: "DE", name: "Germany", flag: "\u{1F1E9}\u{1F1EA}" },
  { code: "FR", name: "France", flag: "\u{1F1EB}\u{1F1F7}" },
  { code: "IN", name: "India", flag: "\u{1F1EE}\u{1F1F3}" },
  { code: "JP", name: "Japan", flag: "\u{1F1EF}\u{1F1F5}" },
  { code: "BR", name: "Brazil", flag: "\u{1F1E7}\u{1F1F7}" },
  { code: "MX", name: "Mexico", flag: "\u{1F1F2}\u{1F1FD}" },
  { code: "NG", name: "Nigeria", flag: "\u{1F1F3}\u{1F1EC}" },
  { code: "ZA", name: "South Africa", flag: "\u{1F1FF}\u{1F1E6}" },
  { code: "SG", name: "Singapore", flag: "\u{1F1F8}\u{1F1EC}" },
  { code: "AE", name: "UAE", flag: "\u{1F1E6}\u{1F1EA}" },
  { code: "EG", name: "Egypt", flag: "\u{1F1EA}\u{1F1EC}" },
  { code: "KR", name: "South Korea", flag: "\u{1F1F0}\u{1F1F7}" },
  { code: "IT", name: "Italy", flag: "\u{1F1EE}\u{1F1F9}" },
  { code: "ES", name: "Spain", flag: "\u{1F1EA}\u{1F1F8}" },
  { code: "NL", name: "Netherlands", flag: "\u{1F1F3}\u{1F1F1}" },
  { code: "PH", name: "Philippines", flag: "\u{1F1F5}\u{1F1ED}" },
];
function CountrySelect({ value, onChange }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const selected = countries.find((c) => c.code === value);
  const filtered = countries.filter(
    (c) =>
      c.name.toLowerCase().includes(query.toLowerCase()) ||
      c.code.toLowerCase().includes(query.toLowerCase()),
  );
  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className={cn(
          "flex h-11 w-full items-center gap-2 rounded-xl border bg-background px-3 text-sm font-medium transition-all",
          open ? "border-ring ring-2 ring-ring/30" : "border-input hover:border-ring/50",
          !selected && "text-muted-foreground",
        )}
      >
        {selected ? (
          <>
            <span className="text-base">{selected.flag}</span>
            <span className="flex-1 text-left text-foreground">{selected.name}</span>
          </>
        ) : (
          <span className="flex-1 text-left text-muted-foreground">Select your country</span>
        )}
        <ChevronDown
          className={cn("h-4 w-4 text-muted-foreground transition-transform", open && "rotate-180")}
        />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.97 }}
            transition={{ duration: 0.18, ease: "easeOut" }}
            className="absolute left-0 right-0 top-full z-50 mt-1.5 overflow-hidden rounded-xl border border-border bg-card shadow-lifted"
          >
            <div className="border-b border-border p-2">
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search country…"
                className="h-8 w-full rounded-lg border-0 bg-muted px-3 text-sm text-foreground outline-none placeholder:text-muted-foreground"
              />
            </div>
            <div className="max-h-52 overflow-y-auto py-1">
              {filtered.map((c) => (
                <button
                  key={c.code}
                  type="button"
                  onClick={() => {
                    onChange(c.code);
                    setOpen(false);
                    setQuery("");
                  }}
                  className={cn(
                    "flex w-full items-center gap-2.5 px-3 py-2 text-left text-sm transition-colors hover:bg-muted",
                    value === c.code && "bg-accent/10 text-accent",
                  )}
                >
                  <span className="text-base">{c.flag}</span>
                  <span className="text-foreground">{c.name}</span>
                  <span className="ml-auto text-xs text-muted-foreground">{c.code}</span>
                </button>
              ))}
              {filtered.length === 0 && (
                <p className="py-4 text-center text-sm text-muted-foreground">No countries found</p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
function RegisterPage() {
  const [loading, setLoading] = useState(false);
  const [showPwd, setShowPwd] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [showPin, setShowPin] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [errors, setErrors] = useState({});
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    username: "",
    email: "",
    phone: "",
    country: "",
    password: "",
    confirmPassword: "",
    transPin: "",
  });
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();
  const update = (field, value) => {
    setForm((f) => ({ ...f, [field]: value }));
    if (errors[field]) setErrors((e) => ({ ...e, [field]: "" }));
  };
  const pwdStrength = (() => {
    const p = form.password;
    let s = 0;
    if (p.length >= 8) s++;
    if (/[A-Z]/.test(p)) s++;
    if (/[0-9]/.test(p)) s++;
    if (/[^A-Za-z0-9]/.test(p)) s++;
    return s;
  })();
  const pwdColors = ["bg-destructive", "bg-destructive", "bg-warning", "bg-accent", "bg-accent"];
  const pwdLabels = ["", "Weak", "Fair", "Good", "Strong"];
  const validate = () => {
    const e = {};
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(form.username))
      e.username = "3\u201320 chars: letters, numbers, underscore";
    if (!/^\d{4,6}$/.test(form.transPin)) e.transPin = "TransPIN must be 4\u20136 digits";
    if (form.password !== form.confirmPassword) e.confirmPassword = "Passwords do not match";
    setErrors(e);
    return Object.keys(e).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!agreed) return;
    if (!validate()) return;
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1500));
    setLoading(false);
    navigate("/otp-verify");
  };
  return (
    <div className="flex min-h-screen bg-background">
      {/* ── Left Panel ── */}
      <motion.div
        initial={{ x: -60, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="gradient-hero relative hidden flex-col justify-between overflow-hidden p-12 lg:flex lg:w-5/12"
      >
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute -right-20 top-20 h-96 w-96 animate-pulse-glow rounded-full opacity-[0.12]"
            style={{ background: "radial-gradient(circle, hsl(162 100% 44%), transparent)" }}
          />
          <div
            className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full opacity-[0.06]"
            style={{ background: "radial-gradient(circle, hsl(213 70% 40%), transparent)" }}
          />
          <div
            className="absolute inset-0 opacity-[0.04]"
            style={{
              backgroundImage:
                "linear-gradient(hsl(0 0% 100%) 1px, transparent 1px), linear-gradient(90deg, hsl(0 0% 100%) 1px, transparent 1px)",
              backgroundSize: "40px 40px",
            }}
          />
        </div>
        <Link
          to="/"
          className="relative z-10 flex items-center gap-2 font-display text-xl font-bold text-primary-foreground"
        >
          <div className="gradient-accent flex h-8 w-8 items-center justify-center rounded-lg shadow-glow">
            <Shield className="h-4 w-4 text-accent-foreground" />
          </div>
          Secure<span className="text-accent">Wallet</span>
        </Link>
        <motion.div
          variants={stagger}
          initial="hidden"
          animate="visible"
          className="relative z-10 space-y-8"
        >
          <motion.div variants={fadeUp} custom={0}>
            <h2 className="mb-3 font-display text-3xl font-bold leading-tight text-primary-foreground">
              Join 2.4M+ users managing money <span className="text-accent">securely</span>
            </h2>
            <p className="text-sm leading-relaxed text-primary-foreground/65">
              Free forever. No hidden fees. Enterprise-grade security for everyone.
            </p>
          </motion.div>
          <motion.div variants={stagger} className="space-y-3">
            {benefits.map(({ icon: Icon, text }, i) => (
              <motion.div
                key={text}
                variants={fadeUp}
                custom={i}
                className="flex items-center gap-3"
              >
                <div className="gradient-accent flex h-8 w-8 shrink-0 items-center justify-center rounded-lg">
                  <Icon className="h-4 w-4 text-accent-foreground" />
                </div>
                <span className="text-sm font-medium text-primary-foreground/85">{text}</span>
              </motion.div>
            ))}
          </motion.div>
          <motion.div
            variants={fadeUp}
            custom={4}
            className="glass rounded-2xl border border-primary-foreground/10 p-5"
          >
            <div className="mb-3 flex gap-1">
              {Array.from({ length: testimonial.stars }).map((_, i) => (
                <Star key={i} className="h-3.5 w-3.5 fill-warning text-warning" />
              ))}
            </div>
            <p className="mb-4 text-sm italic leading-relaxed text-primary-foreground/80">
              "{testimonial.text}"
            </p>
            <div className="flex items-center gap-2">
              <div className="gradient-card flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold text-primary-foreground">
                {testimonial.avatar}
              </div>
              <div>
                <p className="text-xs font-semibold text-primary-foreground">{testimonial.name}</p>
                <p className="text-xs text-primary-foreground/55">{testimonial.role}</p>
              </div>
            </div>
          </motion.div>
        </motion.div>
        <p className="relative z-10 text-xs text-primary-foreground/30">
          © 2025 SecureWallet. All rights reserved.
        </p>
      </motion.div>
      {/* ── Right Panel ── */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.25 }}
        className="relative flex flex-1 flex-col justify-center overflow-y-auto bg-background px-6 py-10"
      >
        <div className="absolute right-4 top-4">
          <button
            onClick={toggleTheme}
            className="rounded-lg p-2 text-muted-foreground transition-all hover:bg-muted hover:text-foreground"
          >
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
        </div>
        <motion.div
          variants={stagger}
          initial="hidden"
          animate="visible"
          className="mx-auto w-full max-w-md"
        >
          <motion.div variants={fadeDown} custom={0}>
            <Link
              to="/"
              className="mb-8 flex items-center gap-2 font-display text-xl font-bold lg:hidden"
            >
              <div className="gradient-accent flex h-8 w-8 items-center justify-center rounded-lg shadow-glow">
                <Shield className="h-4 w-4 text-accent-foreground" />
              </div>
              Secure<span className="text-accent">Wallet</span>
            </Link>
          </motion.div>
          <motion.div variants={fadeUp} custom={0}>
            <h1 className="mb-1 font-display text-3xl font-bold text-foreground">Create account</h1>
            <p className="mb-8 text-sm text-muted-foreground">
              Already have an account?{" "}
              <Link to="/login" className="font-medium text-accent hover:underline">
                Sign in
              </Link>
            </p>
          </motion.div>
          {/* Social signup */}
          <motion.div variants={fadeUp} custom={1} className="mb-6 grid grid-cols-2 gap-3">
            {[
              { label: "Google", icon: "G" },
              { label: "Apple", icon: "\u{1F34E}" },
            ].map(({ label, icon }) => (
              <button
                key={label}
                className="flex h-11 items-center justify-center gap-2 rounded-xl border border-border bg-card text-sm font-medium text-foreground transition-colors hover:bg-muted"
              >
                <span className="text-base">{icon}</span>
                Continue with {label}
              </button>
            ))}
          </motion.div>
          <motion.div variants={fadeUp} custom={2} className="relative mb-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border" />
            </div>
            <div className="relative flex justify-center">
              <span className="bg-background px-3 text-xs text-muted-foreground">
                or register with email
              </span>
            </div>
          </motion.div>
          <motion.form variants={stagger} onSubmit={handleSubmit} className="space-y-4">
            {/* Name row */}
            <motion.div variants={fadeUp} custom={0} className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="firstName" className="text-xs font-medium text-foreground">
                  First name
                </Label>
                <div className="relative mt-1.5">
                  <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="firstName"
                    placeholder="John"
                    className="h-11 pl-10"
                    value={form.firstName}
                    onChange={(e) => update("firstName", e.target.value)}
                    required
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="lastName" className="text-xs font-medium text-foreground">
                  Last name
                </Label>
                <div className="mt-1.5">
                  <Input
                    id="lastName"
                    placeholder="Doe"
                    className="h-11"
                    value={form.lastName}
                    onChange={(e) => update("lastName", e.target.value)}
                    required
                  />
                </div>
              </div>
            </motion.div>
            {/* Username */}
            <motion.div variants={fadeUp} custom={1}>
              <Label htmlFor="username" className="text-xs font-medium text-foreground">
                Username
              </Label>
              <div className="relative mt-1.5">
                <AtSign className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="username"
                  placeholder="johndoe"
                  className="h-11 pl-10"
                  value={form.username}
                  onChange={(e) => update("username", e.target.value.replace(/\s/g, ""))}
                  maxLength={20}
                  required
                />
              </div>
              {errors.username && (
                <p className="mt-1 text-xs text-destructive">{errors.username}</p>
              )}
            </motion.div>
            {/* Email */}
            <motion.div variants={fadeUp} custom={1}>
              <Label htmlFor="email" className="text-xs font-medium text-foreground">
                Email address
              </Label>
              <div className="relative mt-1.5">
                <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  className="h-11 pl-10"
                  value={form.email}
                  onChange={(e) => update("email", e.target.value)}
                  required
                />
              </div>
            </motion.div>
            {/* Phone */}
            <motion.div variants={fadeUp} custom={2}>
              <Label htmlFor="phone" className="text-xs font-medium text-foreground">
                Phone number
              </Label>
              <div className="relative mt-1.5">
                <Phone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="phone"
                  placeholder="+1 (555) 000-0000"
                  className="h-11 pl-10"
                  value={form.phone}
                  onChange={(e) => update("phone", e.target.value)}
                  required
                />
              </div>
            </motion.div>
            {/* Country */}
            <motion.div variants={fadeUp} custom={3}>
              <Label className="text-xs font-medium text-foreground">Country</Label>
              <div className="mt-1.5">
                <CountrySelect value={form.country} onChange={(v) => update("country", v)} />
              </div>
            </motion.div>
            {/* Password */}
            <motion.div variants={fadeUp} custom={4}>
              <Label htmlFor="password" className="text-xs font-medium text-foreground">
                Password
              </Label>
              <div className="relative mt-1.5">
                <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPwd ? "text" : "password"}
                  placeholder="Min. 8 characters"
                  className="h-11 pl-10 pr-10"
                  value={form.password}
                  onChange={(e) => update("password", e.target.value)}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPwd(!showPwd)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground transition-colors hover:text-foreground"
                >
                  {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {form.password && (
                <div className="mt-2 space-y-1">
                  <div className="flex gap-1">
                    {[1, 2, 3, 4].map((i) => (
                      <div
                        key={i}
                        className={cn(
                          "h-1 flex-1 rounded-full transition-all duration-300",
                          i <= pwdStrength ? pwdColors[pwdStrength] : "bg-muted",
                        )}
                      />
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground">{pwdLabels[pwdStrength]} password</p>
                </div>
              )}
            </motion.div>
            {/* Confirm Password */}
            <motion.div variants={fadeUp} custom={5}>
              <Label htmlFor="confirmPwd" className="text-xs font-medium text-foreground">
                Confirm password
              </Label>
              <div className="relative mt-1.5">
                <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="confirmPwd"
                  type={showConfirm ? "text" : "password"}
                  placeholder="Repeat password"
                  className="h-11 pl-10 pr-10"
                  value={form.confirmPassword}
                  onChange={(e) => update("confirmPassword", e.target.value)}
                  required
                />
                <div className="absolute right-3 top-1/2 flex -translate-y-1/2 items-center gap-1">
                  {form.confirmPassword &&
                    (form.password === form.confirmPassword ? (
                      <Check className="h-4 w-4 text-accent" />
                    ) : (
                      <span className="text-xs font-bold text-destructive">✗</span>
                    ))}
                  <button
                    type="button"
                    onClick={() => setShowConfirm(!showConfirm)}
                    className="ml-1 text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {showConfirm ? (
                      <EyeOff className="h-3.5 w-3.5" />
                    ) : (
                      <Eye className="h-3.5 w-3.5" />
                    )}
                  </button>
                </div>
              </div>
              {errors.confirmPassword && (
                <p className="mt-1 text-xs text-destructive">{errors.confirmPassword}</p>
              )}
            </motion.div>
            {/* TransPIN */}
            <motion.div variants={fadeUp} custom={6}>
              <Label htmlFor="transPin" className="text-xs font-medium text-foreground">
                Transaction PIN
                <span className="ml-1 font-normal text-muted-foreground">(4–6 digits)</span>
              </Label>
              <div className="relative mt-1.5">
                <KeyRound className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="transPin"
                  type={showPin ? "text" : "password"}
                  inputMode="numeric"
                  placeholder="••••"
                  className="h-11 pl-10 pr-10 tracking-[0.4em]"
                  maxLength={6}
                  value={form.transPin}
                  onChange={(e) =>
                    update("transPin", e.target.value.replace(/\D/g, "").slice(0, 6))
                  }
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPin(!showPin)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground transition-colors hover:text-foreground"
                >
                  {showPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {errors.transPin ? (
                <p className="mt-1 text-xs text-destructive">{errors.transPin}</p>
              ) : (
                <p className="mt-1 text-xs text-muted-foreground">
                  Used to authorize sensitive transactions.
                </p>
              )}
            </motion.div>
            {/* Terms */}
            <motion.div
              variants={fadeUp}
              custom={6}
              className="flex items-start gap-3 rounded-xl border border-accent/20 bg-accent/5 p-4"
            >
              <Checkbox
                id="terms"
                checked={agreed}
                onCheckedChange={(v) => setAgreed(!!v)}
                className="mt-0.5"
              />
              <label
                htmlFor="terms"
                className="cursor-pointer text-sm leading-relaxed text-foreground/85"
              >
                I agree to the{" "}
                <Link to="/terms" className="font-medium text-accent hover:underline">
                  Terms & Conditions
                </Link>{" "}
                and{" "}
                <Link to="/privacy" className="font-medium text-accent hover:underline">
                  Privacy Policy
                </Link>
              </label>
            </motion.div>
            <motion.div variants={fadeUp} custom={7}>
              <Button
                type="submit"
                variant="accent"
                size="lg"
                className="h-12 w-full text-base shadow-glow"
                disabled={!agreed || loading || !form.country}
              >
                {loading ? (
                  <div className="flex items-center gap-2">
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-accent-foreground/30 border-t-accent-foreground" />
                    Creating account...
                  </div>
                ) : (
                  <>
                    Create Free Account <ArrowRight className="ml-1 h-4 w-4" />
                  </>
                )}
              </Button>
            </motion.div>
          </motion.form>
          <motion.div
            variants={fadeUp}
            initial="hidden"
            animate="visible"
            custom={9}
            className="mt-6 flex items-center justify-center"
          >
            <div className="secure-badge">
              <Shield className="h-3 w-3" />
              Your data is encrypted and secure
            </div>
          </motion.div>
        </motion.div>
      </motion.div>
    </div>
  );
}
export { RegisterPage as default };
