import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Shield,
  Eye,
  EyeOff,
  Mail,
  Lock,
  ArrowRight,
  Fingerprint,
  TrendingUp,
  Send,
  CheckCircle,
  Star,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useTheme } from "@/hooks/use-theme";
import { Moon, Sun } from "lucide-react";
import { motion } from "framer-motion";
import { fadeDown, fadeUp, stagger } from "@/lib/motion";
const highlights = [
  { icon: Shield, label: "256-bit SSL Encryption" },
  { icon: CheckCircle, label: "Real-time fraud monitoring" },
  { icon: Fingerprint, label: "Biometric authentication" },
  { icon: TrendingUp, label: "Smart analytics & insights" },
];
const recentTx = [
  { name: "Netflix", amount: "-$15.99", color: "text-destructive" },
  { name: "Salary Deposit", amount: "+$5,200", color: "text-accent" },
  { name: "Amazon", amount: "-$89.99", color: "text-destructive" },
];
function LoginPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1500));
    setLoading(false);
    navigate("/2fa");
  };
  return (
    <div className="flex min-h-screen bg-background">
      {/* ── Left Panel ── */}
      <motion.div
        initial={{ x: -60, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
        className="gradient-hero relative hidden flex-col justify-between overflow-hidden p-12 lg:flex lg:w-[52%]"
      >
        {/* Decorative glows */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute right-0 top-10 h-[480px] w-[480px] animate-pulse-glow rounded-full opacity-[0.11]"
            style={{ background: "radial-gradient(circle, hsl(162 100% 44%), transparent)" }}
          />
          <div
            className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full opacity-[0.06]"
            style={{ background: "radial-gradient(circle, hsl(213 70% 40%), transparent)" }}
          />
          <div
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage:
                "linear-gradient(hsl(0 0% 100%) 1px, transparent 1px), linear-gradient(90deg, hsl(0 0% 100%) 1px, transparent 1px)",
              backgroundSize: "40px 40px",
            }}
          />
        </div>
        {/* Logo */}
        <Link
          to="/"
          className="relative z-10 flex items-center gap-2.5 font-display text-xl font-bold text-primary-foreground"
        >
          <div className="gradient-accent flex h-9 w-9 items-center justify-center rounded-xl shadow-glow">
            <Shield className="w-4.5 h-4.5 text-accent-foreground" />
          </div>
          Secure<span className="text-accent">Wallet</span>
        </Link>
        {/* Center content */}
        <motion.div
          variants={stagger}
          initial="hidden"
          animate="visible"
          className="relative z-10 space-y-8"
        >
          <motion.div variants={fadeUp} custom={0}>
            <h2 className="mb-3 font-display text-4xl font-bold leading-tight text-primary-foreground">
              Welcome back to your <span className="text-accent">financial hub</span>
            </h2>
            <p className="max-w-sm text-sm leading-relaxed text-primary-foreground/60">
              Manage your money with confidence. Your security is our top priority.
            </p>
          </motion.div>
          {/* Security highlights */}
          <motion.div variants={stagger} className="space-y-2.5">
            {highlights.map(({ icon: Icon, label }, i) => (
              <motion.div
                key={label}
                variants={fadeUp}
                custom={i}
                className="flex items-center gap-3"
              >
                <div className="gradient-accent flex h-8 w-8 shrink-0 items-center justify-center rounded-xl">
                  <Icon className="h-3.5 w-3.5 text-accent-foreground" />
                </div>
                <span className="text-sm font-medium text-primary-foreground/80">{label}</span>
              </motion.div>
            ))}
          </motion.div>
          {/* Mini balance card */}
          <motion.div
            variants={fadeUp}
            custom={4}
            className="glass max-w-xs animate-float rounded-2xl border border-primary-foreground/10 p-5"
          >
            <div className="mb-3 flex items-center justify-between">
              <div>
                <p className="mb-0.5 text-[11px] uppercase tracking-wide text-primary-foreground/50">
                  Total Balance
                </p>
                <p className="font-display text-2xl font-bold text-primary-foreground">
                  $48,250.00
                </p>
              </div>
              <div className="flex items-center gap-1 rounded-full border border-accent/30 bg-accent/20 px-2.5 py-1">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-accent" />
                <span className="text-[10px] font-bold text-accent">LIVE</span>
              </div>
            </div>
            <div className="mb-4 flex items-center gap-1.5">
              <TrendingUp className="h-3 w-3 text-accent" />
              <span className="text-xs font-semibold text-accent">+12.4% this month</span>
            </div>
            <div className="space-y-2">
              {recentTx.map((tx) => (
                <div
                  key={tx.name}
                  className="border-primary-foreground/8 flex items-center justify-between border-b py-1.5 last:border-0"
                >
                  <div className="flex items-center gap-2">
                    <div className="flex h-5 w-5 items-center justify-center rounded-lg bg-primary-foreground/10">
                      <Send className="h-2.5 w-2.5 text-primary-foreground/40" />
                    </div>
                    <span className="text-xs text-primary-foreground/70">{tx.name}</span>
                  </div>
                  <span className={`text-xs font-semibold tabular-nums ${tx.color}`}>
                    {tx.amount}
                  </span>
                </div>
              ))}
            </div>
          </motion.div>
          {/* Rating */}
          <motion.div variants={fadeUp} custom={5} className="flex items-center gap-3">
            <div className="flex gap-0.5">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="h-3.5 w-3.5 fill-warning text-warning" />
              ))}
            </div>
            <span className="text-xs text-primary-foreground/55">4.9/5 from 50,000+ reviews</span>
          </motion.div>
        </motion.div>
        <p className="relative z-10 text-xs text-primary-foreground/25">
          © 2025 SecureWallet. All rights reserved.
        </p>
      </motion.div>
      {/* ── Right Panel ── */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.15 }}
        className="relative flex flex-1 flex-col justify-center overflow-y-auto bg-background px-6 py-12"
      >
        {/* Theme toggle */}
        <div className="absolute right-4 top-4">
          <button
            onClick={toggleTheme}
            className="rounded-lg p-2 text-muted-foreground transition-all hover:bg-muted hover:text-foreground"
          >
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
        </div>
        <motion.div
          variants={stagger}
          initial="hidden"
          animate="visible"
          className="mx-auto w-full max-w-[400px]"
        >
          {/* Mobile logo */}
          <motion.div variants={fadeDown} custom={0}>
            <Link
              to="/"
              className="mb-8 flex items-center gap-2 font-display text-xl font-bold lg:hidden"
            >
              <div className="gradient-accent flex h-8 w-8 items-center justify-center rounded-xl shadow-glow">
                <Shield className="h-4 w-4 text-accent-foreground" />
              </div>
              Secure<span className="text-accent">Wallet</span>
            </Link>
          </motion.div>
          {/* Heading */}
          <motion.div variants={fadeUp} custom={0} className="mb-7">
            <h1 className="mb-1.5 font-display text-3xl font-bold text-foreground">Sign in</h1>
            <p className="text-sm text-muted-foreground">
              Don't have an account?{" "}
              <Link
                to="/register"
                className="font-semibold text-accent transition-colors hover:text-accent/80"
              >
                Create one free
              </Link>
            </p>
          </motion.div>
          {/* Social logins */}
          <motion.div variants={fadeUp} custom={1} className="mb-5 grid grid-cols-2 gap-3">
            {[
              { label: "Google", icon: "G" },
              { label: "Apple", icon: "\u{1F34E}" },
            ].map(({ label, icon }) => (
              <button
                key={label}
                className="flex h-11 items-center justify-center gap-2 rounded-xl border border-border bg-card text-sm font-medium text-foreground transition-all hover:bg-muted active:scale-[0.98]"
              >
                <span className="text-base leading-none">{icon}</span>
                <span>Continue with {label}</span>
              </button>
            ))}
          </motion.div>
          {/* Divider */}
          <motion.div variants={fadeUp} custom={2} className="relative mb-5">
            <Separator />
            <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-background px-3 text-xs text-muted-foreground">
              or sign in with email
            </span>
          </motion.div>
          {/* Form */}
          <motion.form variants={stagger} onSubmit={handleSubmit} className="space-y-4">
            {/* Email */}
            <motion.div variants={fadeUp} custom={0}>
              <Label
                htmlFor="email"
                className="mb-1.5 block text-xs font-semibold text-foreground/80"
              >
                Email address
              </Label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground/70" />
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  className="pl-10"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </motion.div>
            {/* Password */}
            <motion.div variants={fadeUp} custom={1}>
              <div className="mb-1.5 flex items-center justify-between">
                <Label htmlFor="password" className="text-xs font-semibold text-foreground/80">
                  Password
                </Label>
                <Link
                  to="/forgot-password"
                  className="text-xs font-medium text-accent transition-colors hover:text-accent/80"
                >
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground/70" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  className="pl-10 pr-11"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground/60 transition-colors hover:text-muted-foreground"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </motion.div>
            {/* Submit */}
            <motion.div variants={fadeUp} custom={2} className="pt-1">
              <Button
                type="submit"
                variant="accent"
                size="lg"
                className="group h-12 w-full text-[15px] font-semibold shadow-glow"
                disabled={loading}
              >
                {loading ? (
                  <div className="flex items-center gap-2">
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-accent-foreground/30 border-t-accent-foreground" />
                    Signing in...
                  </div>
                ) : (
                  <>
                    Sign in
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                  </>
                )}
              </Button>
            </motion.div>
          </motion.form>
          {/* Biometric */}
          <motion.button
            variants={fadeUp}
            initial="hidden"
            animate="visible"
            custom={5}
            className="mt-3 flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-dashed border-border text-sm text-muted-foreground transition-all hover:border-accent/40 hover:bg-accent/5 hover:text-accent"
          >
            <Fingerprint className="h-4 w-4" />
            Use biometric authentication
          </motion.button>
          {/* Security notice */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            animate="visible"
            custom={6}
            className="mt-5 flex items-center justify-center"
          >
            <div className="secure-badge">
              <Shield className="h-3 w-3" />
              Secured by 256-bit encryption
            </div>
          </motion.div>
        </motion.div>
      </motion.div>
    </div>
  );
}
export { LoginPage as default };
