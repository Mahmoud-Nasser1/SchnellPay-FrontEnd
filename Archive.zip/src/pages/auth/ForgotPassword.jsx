import { useState } from "react";
import { Link } from "react-router-dom";
import { Shield, Mail, ArrowLeft, ArrowRight, Lock, Check, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
function ForgotPasswordPage() {
  const [step, setStep] = useState("email");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1500));
    setLoading(false);
    setStep("sent");
  };
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <Link
            to="/"
            className="mb-8 inline-flex items-center gap-2 font-display text-xl font-bold"
          >
            <div className="gradient-accent flex h-8 w-8 items-center justify-center rounded-lg shadow-glow">
              <Shield className="h-4 w-4 text-accent-foreground" />
            </div>
            Secure<span className="text-accent">Wallet</span>
          </Link>
        </div>
        <div className="glass-card rounded-2xl p-8">
          {step === "email" ? (
            <>
              <div className="gradient-card mb-6 flex h-14 w-14 items-center justify-center rounded-2xl shadow-navy">
                <Lock className="h-7 w-7 text-accent" />
              </div>
              <h1 className="mb-2 font-display text-2xl font-bold text-foreground">
                Forgot your password?
              </h1>
              <p className="mb-6 text-sm text-muted-foreground">
                No worries. Enter your email and we'll send reset instructions.
              </p>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="email">Email address</Label>
                  <div className="relative mt-1.5">
                    <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@example.com"
                      className="pl-10"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>
                <Button
                  type="submit"
                  variant="accent"
                  size="lg"
                  className="w-full shadow-glow"
                  disabled={loading}
                >
                  {loading ? (
                    <div className="flex items-center gap-2">
                      <div className="h-4 w-4 animate-spin rounded-full border-2 border-accent-foreground/30 border-t-accent-foreground" />
                      Sending...
                    </div>
                  ) : (
                    <>
                      Send Reset Link <ArrowRight className="ml-1 h-4 w-4" />
                    </>
                  )}
                </Button>
              </form>
            </>
          ) : (
            <div className="text-center">
              <div className="gradient-success mx-auto mb-6 flex h-16 w-16 animate-bounce-in items-center justify-center rounded-full shadow-glow">
                <Check className="h-8 w-8 text-accent-foreground" />
              </div>
              <h2 className="mb-2 font-display text-2xl font-bold text-foreground">
                Check your email
              </h2>
              <p className="mb-6 text-sm text-muted-foreground">
                We sent a password reset link to{" "}
                <strong className="text-foreground">{email}</strong>. Check your spam folder if you
                don't see it.
              </p>
              <Button variant="outline" size="lg" className="mb-3 w-full" asChild>
                <a href="https://mail.google.com" target="_blank">
                  Open Gmail
                </a>
              </Button>
              <button
                onClick={() => setStep("email")}
                className="text-sm text-accent hover:underline"
              >
                Try a different email
              </button>
            </div>
          )}
          <div className="mt-6 text-center">
            <Link
              to="/login"
              className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Back to sign in
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
function ResetPasswordPage() {
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [password, setPassword] = useState("");
  const handleReset = async (e) => {
    e.preventDefault();
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1500));
    setLoading(false);
    setDone(true);
  };
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <Link
            to="/"
            className="mb-8 inline-flex items-center gap-2 font-display text-xl font-bold"
          >
            <div className="gradient-accent flex h-8 w-8 items-center justify-center rounded-lg shadow-glow">
              <Shield className="h-4 w-4 text-accent-foreground" />
            </div>
            Secure<span className="text-accent">Wallet</span>
          </Link>
        </div>
        <div className="glass-card rounded-2xl p-8">
          {!done ? (
            <>
              <h1 className="mb-2 font-display text-2xl font-bold text-foreground">
                Set new password
              </h1>
              <p className="mb-6 text-sm text-muted-foreground">Must be at least 8 characters.</p>
              <form onSubmit={handleReset} className="space-y-4">
                <div>
                  <Label htmlFor="newPwd">New password</Label>
                  <div className="relative mt-1.5">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="newPwd"
                      type={showPwd ? "text" : "password"}
                      placeholder="Min. 8 characters"
                      className="pl-10 pr-10"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPwd(!showPwd)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <Label htmlFor="confirmPwd">Confirm password</Label>
                  <div className="relative mt-1.5">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="confirmPwd"
                      type="password"
                      placeholder="Repeat password"
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                <Button
                  type="submit"
                  variant="accent"
                  size="lg"
                  className="w-full shadow-glow"
                  disabled={loading}
                >
                  {loading ? (
                    <div className="flex items-center gap-2">
                      <div className="h-4 w-4 animate-spin rounded-full border-2 border-accent-foreground/30 border-t-accent-foreground" />
                      Updating...
                    </div>
                  ) : (
                    <>
                      Update Password <ArrowRight className="ml-1 h-4 w-4" />
                    </>
                  )}
                </Button>
              </form>
            </>
          ) : (
            <div className="text-center">
              <div className="gradient-success mx-auto mb-6 flex h-16 w-16 animate-bounce-in items-center justify-center rounded-full shadow-glow">
                <Check className="h-8 w-8 text-accent-foreground" />
              </div>
              <h2 className="mb-2 font-display text-2xl font-bold text-foreground">
                Password updated!
              </h2>
              <p className="mb-6 text-sm text-muted-foreground">
                Your password has been changed successfully.
              </p>
              <Button variant="accent" size="lg" className="w-full shadow-glow" asChild>
                <Link to="/login">Sign In Now</Link>
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
export { ResetPasswordPage, ForgotPasswordPage as default };
