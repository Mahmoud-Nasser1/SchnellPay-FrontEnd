import PublicNav from "@/components/PublicNav";
import PublicFooter from "@/components/PublicFooter";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { motion } from "framer-motion";
import { fadeUp, fadeDown, scaleIn, stagger, viewport } from "@/lib/motion";
import { HelpCircle, Shield, CreditCard, Globe, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
const faqs = [
  {
    category: "General",
    icon: Globe,
    items: [
      {
        q: "Is SecureWallet free to use?",
        a: "Yes! Creating an account, receiving payments, and internal transfers are completely free. We only charge on currency conversions (0.5%) and instant bank withdrawals.",
      },
      {
        q: "Which countries are supported?",
        a: "SecureWallet is available in 150+ countries. Full KYC verification and fiat currency accounts are available in 80+ countries.",
      },
      {
        q: "How do I get started?",
        a: "Simply create an account, complete KYC verification, and add a payment method. The whole process takes about 5 minutes.",
      },
    ],
  },
  {
    category: "Security",
    icon: Shield,
    items: [
      {
        q: "How is my money protected?",
        a: "Your funds are protected by 256-bit AES encryption, two-factor authentication, and real-time AI fraud detection. We are PCI DSS Level 1 certified.",
      },
      {
        q: "What happens if my account is compromised?",
        a: "Contact us immediately. We can freeze your account within seconds. Our fraud team operates 24/7.",
      },
      {
        q: "Is my personal data safe?",
        a: "We never sell your data. All data is encrypted at rest and in transit. We comply with GDPR, CCPA, and international privacy laws.",
      },
    ],
  },
  {
    category: "Payments",
    icon: CreditCard,
    items: [
      {
        q: "How fast are transfers?",
        a: "Internal transfers between SecureWallet users are instant. Bank withdrawals take 1-2 business days.",
      },
      {
        q: "Is there a transfer limit?",
        a: "Unverified accounts: $500/day. KYC verified accounts: $50,000/day. Business accounts have custom limits.",
      },
      {
        q: "What currencies are supported?",
        a: "We support 50+ currencies. Real-time exchange rates are updated every minute. Conversion fee is just 0.5%.",
      },
    ],
  },
];
function FAQPage() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <PublicNav />
      <main className="flex-1 pt-16">
        {/* Hero */}
        <section className="gradient-hero relative overflow-hidden px-4 py-28 text-center">
          <div className="pointer-events-none absolute inset-0 overflow-hidden">
            <div
              className="absolute right-20 top-10 h-80 w-80 animate-pulse-glow rounded-full opacity-[0.10]"
              style={{ background: "radial-gradient(circle, hsl(162 90% 44%), transparent)" }}
            />
            <div
              className="absolute bottom-0 left-10 h-60 w-60 rounded-full opacity-[0.07]"
              style={{ background: "radial-gradient(circle, hsl(213 85% 50%), transparent)" }}
            />
          </div>
          <div className="container relative z-10 mx-auto max-w-3xl">
            <motion.div variants={stagger} initial="hidden" animate="visible">
              <motion.div
                variants={fadeDown}
                custom={0}
                className="mb-6 inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/10 px-4 py-2"
              >
                <HelpCircle className="h-3.5 w-3.5 text-accent" />
                <span className="text-xs font-semibold uppercase tracking-wide text-accent">
                  Help Center
                </span>
              </motion.div>
              <motion.h1
                variants={fadeUp}
                custom={1}
                className="mb-4 font-display text-5xl font-bold leading-tight text-primary-foreground md:text-6xl"
              >
                Frequently Asked <span className="text-gradient-accent">Questions</span>
              </motion.h1>
              <motion.p
                variants={fadeUp}
                custom={2}
                className="mb-8 text-lg text-primary-foreground/70"
              >
                Everything you need to know about SecureWallet. Can't find an answer?
              </motion.p>
              <motion.div variants={fadeUp} custom={3}>
                <Button variant="accent" size="lg" asChild className="shadow-glow">
                  <Link to="/contact">
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Contact Support
                  </Link>
                </Button>
              </motion.div>
            </motion.div>
          </div>
        </section>
        {/* FAQ Content */}
        <section className="bg-background py-20">
          <div className="container mx-auto max-w-3xl space-y-12 px-4">
            {faqs.map(({ category, icon: Icon, items }, catIdx) => (
              <motion.div
                key={category}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={viewport}
                custom={catIdx}
              >
                <div className="mb-6 flex items-center gap-3">
                  <div className="gradient-accent flex h-9 w-9 items-center justify-center rounded-xl shadow-glow">
                    <Icon className="w-4.5 h-4.5 text-accent-foreground" />
                  </div>
                  <h2 className="font-display text-xl font-bold text-foreground">{category}</h2>
                </div>
                <Accordion type="single" collapsible className="space-y-3">
                  {items.map((faq, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 12 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={viewport}
                      transition={{ delay: i * 0.08, duration: 0.4, ease: "easeOut" }}
                    >
                      <AccordionItem
                        value={`${category}-${i}`}
                        className="rounded-xl border border-border bg-card px-5 shadow-card transition-colors hover:border-accent/30"
                      >
                        <AccordionTrigger className="py-4 text-left font-semibold text-foreground transition-colors hover:text-accent hover:no-underline">
                          {faq.q}
                        </AccordionTrigger>
                        <AccordionContent className="pb-4 text-sm leading-relaxed text-muted-foreground">
                          {faq.a}
                        </AccordionContent>
                      </AccordionItem>
                    </motion.div>
                  ))}
                </Accordion>
              </motion.div>
            ))}
          </div>
        </section>
        {/* CTA */}
        <motion.section
          variants={scaleIn}
          initial="hidden"
          whileInView="visible"
          viewport={viewport}
          className="bg-secondary/40 py-20"
        >
          <div className="container mx-auto max-w-2xl px-4 text-center">
            <div className="gradient-accent mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl shadow-glow">
              <MessageSquare className="h-8 w-8 text-accent-foreground" />
            </div>
            <h2 className="mb-4 font-display text-3xl font-bold text-foreground">
              Still have questions?
            </h2>
            <p className="mb-8 text-muted-foreground">
              Our support team responds within 2 hours on business days.
            </p>
            <Button variant="accent" size="lg" asChild className="shadow-glow">
              <Link to="/contact">Contact Us</Link>
            </Button>
          </div>
        </motion.section>
      </main>
      <PublicFooter />
    </div>
  );
}
export { FAQPage as default };
