import { useState } from "react";
import { Search, ArrowRight, Check, Shield, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import { fadeUp, fadeDown, scaleUp, stagger } from "@/lib/motion";
import PinVerifyDialog from "@/components/PinVerifyDialog";
const recentContacts = [
  { id: 1, name: "Alice Johnson", email: "alice@example.com", avatar: "AJ", verified: true },
  { id: 2, name: "Bob Smith", email: "bob@example.com", avatar: "BS", verified: true },
  { id: 3, name: "Carol White", email: "carol@example.com", avatar: "CW", verified: false },
  { id: 4, name: "David Lee", email: "david@example.com", avatar: "DL", verified: true },
];
function SendMoneyPage() {
  const [step, setStep] = useState("recipient");
  const [selected, setSelected] = useState(null);
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [pinOpen, setPinOpen] = useState(false);
  const handleSend = async () => {
    setLoading(true);
    await new Promise((r) => setTimeout(r, 2e3));
    setLoading(false);
    setStep("success");
  };
  const steps = ["Recipient", "Amount", "Confirm"];
  const stepIndex = { recipient: 0, amount: 1, confirm: 2, success: 3 };
  return (
    <motion.div
      variants={stagger}
      initial="hidden"
      animate="visible"
      className="mx-auto max-w-lg space-y-6"
    >
      <motion.div variants={fadeDown} custom={0}>
        <h1 className="font-display text-2xl font-bold text-foreground">Send Money</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Fast, secure transfers to anyone worldwide
        </p>
      </motion.div>
      {step !== "success" && (
        <motion.div variants={fadeUp} custom={1} className="flex items-center gap-2">
          {steps.map((s, i) => (
            <div key={s} className="flex items-center gap-2">
              <div
                className={cn(
                  "flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold transition-all",
                  i < stepIndex[step]
                    ? "gradient-accent text-accent-foreground"
                    : i === stepIndex[step]
                      ? "border-2 border-accent bg-accent/10 text-accent"
                      : "border-2 border-border text-muted-foreground",
                )}
              >
                {i < stepIndex[step] ? <Check className="h-3.5 w-3.5" /> : i + 1}
              </div>
              <span
                className={cn(
                  "hidden text-sm font-medium sm:block",
                  i === stepIndex[step] ? "text-foreground" : "text-muted-foreground",
                )}
              >
                {s}
              </span>
              {i < 2 && (
                <div
                  className={cn(
                    "mx-1 h-px flex-1",
                    i < stepIndex[step] ? "bg-accent" : "bg-border",
                  )}
                  style={{ minWidth: "20px" }}
                />
              )}
            </div>
          ))}
        </motion.div>
      )}
      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          className="rounded-2xl border border-border bg-card p-6 shadow-card"
        >
          {step === "recipient" && (
            <div className="space-y-5">
              <div>
                <Label className="text-xs font-medium text-foreground">Search recipient</Label>
                <div className="relative mt-1.5">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input placeholder="Name, email, or wallet ID" className="h-11 pl-10" />
                </div>
              </div>
              <div>
                <p className="mb-3 text-sm font-medium text-muted-foreground">Recent contacts</p>
                <div className="space-y-2">
                  {recentContacts.map((contact, i) => (
                    <motion.button
                      key={contact.id}
                      initial={{ opacity: 0, x: -16 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.07, duration: 0.35, ease: "easeOut" }}
                      onClick={() => setSelected(contact)}
                      className={cn(
                        "flex w-full items-center gap-3 rounded-xl border p-3 text-left transition-all",
                        selected?.id === contact.id
                          ? "border-accent bg-accent/10"
                          : "border-border hover:border-accent/50 hover:bg-muted/50",
                      )}
                    >
                      <div className="gradient-card flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-xs font-bold text-primary-foreground">
                        {contact.avatar}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <p className="text-sm font-semibold text-foreground">{contact.name}</p>
                          {contact.verified && <Shield className="h-3 w-3 text-accent" />}
                        </div>
                        <p className="text-xs text-muted-foreground">{contact.email}</p>
                      </div>
                      {selected?.id === contact.id && (
                        <Check className="h-4 w-4 shrink-0 text-accent" />
                      )}
                    </motion.button>
                  ))}
                </div>
              </div>
              <Button
                variant="accent"
                size="lg"
                className="w-full shadow-glow"
                disabled={!selected}
                onClick={() => setStep("amount")}
              >
                Continue <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </div>
          )}
          {step === "amount" && selected && (
            <div className="space-y-5">
              <div className="flex items-center gap-3 rounded-xl border border-border bg-muted/50 p-3">
                <div className="gradient-card flex h-10 w-10 items-center justify-center rounded-full text-xs font-bold text-primary-foreground">
                  {selected.avatar}
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">{selected.name}</p>
                  <p className="text-xs text-muted-foreground">{selected.email}</p>
                </div>
              </div>
              <div>
                <Label className="text-xs font-medium text-foreground">Amount</Label>
                <div className="relative mt-1.5">
                  <DollarSign className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    type="number"
                    placeholder="0.00"
                    className="h-14 pl-10 font-display text-2xl font-bold"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                  />
                </div>
                <p className="mt-1.5 text-xs text-muted-foreground">
                  Available balance: <span className="font-semibold text-accent">$46,100.00</span>
                </p>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {["50", "100", "250", "500"].map((q) => (
                  <button
                    key={q}
                    onClick={() => setAmount(q)}
                    className={cn(
                      "rounded-lg border py-2 text-sm font-medium transition-all",
                      amount === q
                        ? "border-accent bg-accent/10 text-accent"
                        : "border-border text-muted-foreground hover:border-accent/50",
                    )}
                  >
                    ${q}
                  </button>
                ))}
              </div>
              <div>
                <Label className="text-xs font-medium text-foreground">Note (optional)</Label>
                <Input
                  className="mt-1.5"
                  placeholder="What's this for?"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                />
              </div>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => setStep("recipient")}
                  className="flex-1"
                >
                  Back
                </Button>
                <Button
                  variant="accent"
                  size="lg"
                  className="flex-1 shadow-glow"
                  disabled={!amount || Number(amount) <= 0}
                  onClick={() => setStep("confirm")}
                >
                  Review <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
          {step === "confirm" && selected && (
            <div className="space-y-5">
              <h3 className="font-display text-lg font-semibold text-foreground">
                Review Transfer
              </h3>
              <div className="space-y-3">
                {[
                  { label: "To", value: `${selected.name} (${selected.email})` },
                  { label: "Amount", value: `$${Number(amount).toFixed(2)}` },
                  { label: "Fee", value: "Free" },
                  { label: "Note", value: note || "\u2014" },
                  { label: "Total", value: `$${Number(amount).toFixed(2)}` },
                ].map(({ label, value }, i) => (
                  <motion.div
                    key={label}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.06 }}
                    className="flex justify-between border-b border-border/50 py-2 last:border-0"
                  >
                    <span className="text-sm text-muted-foreground">{label}</span>
                    <span
                      className={cn(
                        "text-sm font-semibold text-foreground",
                        label === "Total" && "text-base text-accent",
                      )}
                    >
                      {value}
                    </span>
                  </motion.div>
                ))}
              </div>
              <div className="flex items-center gap-2 rounded-xl border border-accent/20 bg-accent/5 p-3">
                <Shield className="h-4 w-4 shrink-0 text-accent" />
                <p className="text-xs text-muted-foreground">
                  This transfer is protected by SecureWallet's fraud detection system.
                </p>
              </div>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => setStep("amount")}
                  className="flex-1"
                >
                  Back
                </Button>
                <Button
                  variant="accent"
                  size="lg"
                  className="flex-1 shadow-glow"
                  onClick={() => setPinOpen(true)}
                  disabled={loading}
                >
                  {loading ? (
                    <div className="flex items-center gap-2">
                      <div className="h-4 w-4 animate-spin rounded-full border-2 border-accent-foreground/30 border-t-accent-foreground" />
                      Sending...
                    </div>
                  ) : (
                    <>Confirm & Send</>
                  )}
                </Button>
              </div>
            </div>
          )}
          {step === "success" && selected && (
            <motion.div
              variants={scaleUp}
              initial="hidden"
              animate="visible"
              className="py-6 text-center"
            >
              <div className="gradient-success mx-auto mb-6 flex h-20 w-20 animate-bounce-in items-center justify-center rounded-full shadow-glow">
                <Check className="h-10 w-10 text-accent-foreground" />
              </div>
              <h2 className="mb-2 font-display text-2xl font-bold text-foreground">
                Transfer Sent!
              </h2>
              <p className="mb-6 text-muted-foreground">
                <span className="font-semibold text-accent">${Number(amount).toFixed(2)}</span> has
                been sent to <span className="font-semibold text-foreground">{selected.name}</span>
              </p>
              <div className="mb-6 space-y-2 rounded-xl border border-border bg-muted/50 p-4 text-left">
                {[
                  { label: "Transaction ID", value: "#TXN-847362" },
                  { label: "Status", value: "\u2713 Completed" },
                  { label: "Date", value: /* @__PURE__ */ new Date().toLocaleDateString() },
                ].map(({ label, value }) => (
                  <div key={label} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{label}</span>
                    <span className="font-medium text-foreground">{value}</span>
                  </div>
                ))}
              </div>
              <div className="flex gap-3">
                <Button variant="outline" className="flex-1">
                  Download Receipt
                </Button>
                <Button
                  variant="accent"
                  className="flex-1 shadow-glow"
                  onClick={() => {
                    setStep("recipient");
                    setSelected(null);
                    setAmount("");
                  }}
                >
                  Send Again
                </Button>
              </div>
            </motion.div>
          )}
        </motion.div>
      </AnimatePresence>
      <PinVerifyDialog
        open={pinOpen}
        onOpenChange={setPinOpen}
        onVerified={handleSend}
        description={`Enter your 6-digit TransPIN to send $${Number(amount || 0).toFixed(2)}.`}
      />
    </motion.div>
  );
}
export { SendMoneyPage as default };
