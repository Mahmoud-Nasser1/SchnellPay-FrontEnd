import { Copy, Share2, Download, QrCode } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { fadeUp, fadeDown, scaleIn, stagger } from "@/lib/motion";
function ReceiveMoneyPage() {
  const [copied, setCopied] = useState(false);
  const walletId = "SW-2847-XQTZ-8834";
  const handleCopy = () => {
    navigator.clipboard.writeText(walletId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2e3);
  };
  return (
    <motion.div
      variants={stagger}
      initial="hidden"
      animate="visible"
      className="mx-auto max-w-md space-y-6"
    >
      <motion.div variants={fadeDown} custom={0}>
        <h1 className="font-display text-2xl font-bold text-foreground">Receive Money</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Share your Wallet ID or QR code to receive payments
        </p>
      </motion.div>
      <motion.div
        variants={fadeUp}
        custom={1}
        className="space-y-6 rounded-2xl border border-border bg-card p-6 text-center shadow-card"
      >
        {/* QR Code */}
        <motion.div variants={scaleIn} custom={0} className="relative">
          <div className="relative mx-auto flex h-48 w-48 items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed border-border bg-muted">
            <div className="grid grid-cols-10 gap-0.5 p-2 opacity-80">
              {Array.from({ length: 100 }).map((_, i) => (
                <div
                  key={i}
                  className={cn(
                    "h-3 w-3 rounded-sm",
                    i % 3 === 0 || i % 7 === 0 ? "bg-foreground" : "bg-transparent",
                  )}
                />
              ))}
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="gradient-accent flex h-10 w-10 items-center justify-center rounded-lg shadow-glow">
                <QrCode className="h-5 w-5 text-accent-foreground" />
              </div>
            </div>
          </div>
          <div className="pointer-events-none absolute inset-0 animate-pulse-glow rounded-2xl border-2 border-accent/20" />
        </motion.div>
        <motion.div variants={fadeUp} custom={1}>
          <p className="mb-2 text-sm text-muted-foreground">Your Wallet ID</p>
          <div className="flex items-center gap-2 rounded-xl border border-border bg-muted/50 p-3">
            <code className="flex-1 text-center font-display text-lg font-bold tracking-widest text-foreground">
              {walletId}
            </code>
          </div>
        </motion.div>
        <motion.div variants={fadeUp} custom={2} className="grid grid-cols-3 gap-3">
          {[
            { icon: Copy, label: copied ? "Copied!" : "Copy", onClick: handleCopy, active: copied },
            { icon: Share2, label: "Share", onClick: () => {}, active: false },
            { icon: Download, label: "Save QR", onClick: () => {}, active: false },
          ].map(({ icon: Icon, label, onClick, active }) => (
            <button
              key={label}
              onClick={onClick}
              className={cn(
                "flex flex-col items-center gap-2 rounded-xl border p-3 transition-all",
                active
                  ? "border-accent bg-accent/10 text-accent"
                  : "border-border text-muted-foreground hover:border-accent/50 hover:text-foreground",
              )}
            >
              <Icon className="h-5 w-5" />
              <span className="text-xs font-medium">{label}</span>
            </button>
          ))}
        </motion.div>
      </motion.div>
      <motion.div
        variants={fadeUp}
        custom={3}
        className="rounded-2xl border border-border bg-card p-5 shadow-card"
      >
        <h3 className="mb-4 font-display font-semibold text-foreground">Request Specific Amount</h3>
        <div className="flex gap-3">
          <input
            type="number"
            placeholder="Enter amount ($)"
            className="h-11 flex-1 rounded-xl border border-input bg-background px-4 text-sm text-foreground transition-all focus:outline-none focus:ring-2 focus:ring-ring/50"
          />
          <Button variant="accent" className="shrink-0 shadow-glow">
            Generate QR
          </Button>
        </div>
      </motion.div>
      <motion.div
        variants={fadeUp}
        custom={4}
        className="flex items-center gap-3 rounded-xl border border-accent/20 bg-accent/5 p-4"
      >
        <div className="gradient-accent flex h-8 w-8 shrink-0 items-center justify-center rounded-lg">
          <QrCode className="h-4 w-4 text-accent-foreground" />
        </div>
        <div>
          <p className="text-xs font-semibold text-foreground">Scan to pay instantly</p>
          <p className="text-xs text-muted-foreground">
            Share your QR with anyone to receive payments in seconds
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
}
export { ReceiveMoneyPage as default };
