import { useState, useRef, useCallback } from "react";
import {
  User,
  Shield,
  Key,
  Smartphone,
  Activity,
  FileCheck,
  Check,
  Lock,
  Eye,
  EyeOff,
  AlertTriangle,
  Upload,
  X,
  File as FileIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import { fadeUp, fadeDown, scaleIn, stagger } from "@/lib/motion";
import { useToast } from "@/hooks/use-toast";
const tabs = [
  { id: "profile", icon: User, label: "Profile" },
  { id: "2fa", icon: Smartphone, label: "2FA" },
  { id: "activity", icon: Activity, label: "Activity Log" },
  { id: "kyc", icon: FileCheck, label: "KYC Status" },
];
const activityLog = [
  {
    id: 1,
    action: "Login",
    device: "Chrome on MacOS",
    location: "San Francisco, CA",
    time: "2 min ago",
    risk: "low",
  },
  {
    id: 2,
    action: "Password Changed",
    device: "Safari on iPhone",
    location: "New York, NY",
    time: "2 days ago",
    risk: "medium",
  },
  {
    id: 3,
    action: "Login",
    device: "Firefox on Windows",
    location: "London, UK",
    time: "5 days ago",
    risk: "high",
  },
  {
    id: 4,
    action: "2FA Enabled",
    device: "Chrome on MacOS",
    location: "San Francisco, CA",
    time: "1 week ago",
    risk: "low",
  },
];
function KycFileUpload({ label, onUpload }) {
  const [dragOver, setDragOver] = useState(false);
  const [uploaded, setUploaded] = useState(null);
  const [preview, setPreview] = useState(null);
  const [progress, setProgress] = useState(0);
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef(null);
  const processFile = useCallback(
    async (file) => {
      if (!["image/jpeg", "image/png", "image/jpg", "application/pdf"].includes(file.type)) {
        return;
      }
      if (file.size > 5 * 1024 * 1024) return;
      setUploading(true);
      setProgress(0);
      for (let i = 0; i <= 100; i += 10) {
        await new Promise((r) => setTimeout(r, 80));
        setProgress(i);
      }
      setUploading(false);
      setUploaded(file);
      if (file.type !== "application/pdf") {
        const url = URL.createObjectURL(file);
        setPreview(url);
      }
      onUpload(file);
    },
    [onUpload],
  );
  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  };
  const handleInput = (e) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };
  const clear = () => {
    setUploaded(null);
    setPreview(null);
    setProgress(0);
    if (inputRef.current) inputRef.current.value = "";
  };
  return (
    <div>
      <Label className="mb-2 block text-xs font-medium text-foreground">{label}</Label>
      {!uploaded ? (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          onClick={() => inputRef.current?.click()}
          className={cn(
            "relative cursor-pointer rounded-xl border-2 border-dashed p-6 text-center transition-all duration-200",
            dragOver
              ? "scale-[1.01] border-accent bg-accent/10"
              : "border-border hover:border-accent/50 hover:bg-muted/30",
          )}
        >
          <input
            ref={inputRef}
            type="file"
            accept=".jpg,.jpeg,.png,.pdf"
            onChange={handleInput}
            className="hidden"
          />
          {uploading ? (
            <div className="space-y-3">
              <div className="gradient-accent mx-auto flex h-10 w-10 animate-pulse items-center justify-center rounded-xl">
                <Upload className="h-5 w-5 text-accent-foreground" />
              </div>
              <p className="text-sm font-medium text-foreground">Uploading...</p>
              <div className="h-1.5 w-full rounded-full bg-muted">
                <motion.div
                  className="gradient-accent h-1.5 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.1 }}
                />
              </div>
              <p className="text-xs text-muted-foreground">{progress}%</p>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-xl bg-muted">
                <Upload className="h-5 w-5 text-muted-foreground" />
              </div>
              <p className="text-sm font-medium text-foreground">Drag & drop or click to upload</p>
              <p className="text-xs text-muted-foreground">JPG, PNG, or PDF · Max 5MB</p>
            </div>
          )}
        </div>
      ) : (
        <motion.div
          variants={scaleIn}
          initial="hidden"
          animate="visible"
          className="relative flex items-center gap-3 rounded-xl border border-accent/40 bg-accent/5 p-4"
        >
          {preview ? (
            <img
              src={preview}
              alt="ID preview"
              className="h-14 w-14 shrink-0 rounded-lg border border-border object-cover"
            />
          ) : (
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-lg bg-muted">
              <FileIcon className="h-7 w-7 text-muted-foreground" />
            </div>
          )}
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold text-foreground">{uploaded.name}</p>
            <p className="text-xs text-muted-foreground">
              {(uploaded.size / 1024).toFixed(1)} KB · Uploaded
            </p>
            <div className="mt-1 flex items-center gap-1">
              <Check className="h-3 w-3 text-accent" />
              <span className="text-xs font-medium text-accent">Ready for review</span>
            </div>
          </div>
          <button
            onClick={clear}
            className="shrink-0 rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </motion.div>
      )}
    </div>
  );
}
function SettingsPage() {
  const [activeTab, setActiveTab] = useState("profile");
  const [twoFaEnabled, setTwoFaEnabled] = useState(true);
  const [emailNotif, setEmailNotif] = useState(true);
  const [smsNotif, setSmsNotif] = useState(false);
  const [showPwd, setShowPwd] = useState(false);
  const [saved, setSaved] = useState(false);
  const [kycUploads, setKycUploads] = useState({});
  const [kycSubmitting, setKycSubmitting] = useState(false);
  const [kycSubmitted, setKycSubmitted] = useState(false);
  const { toast } = useToast();
  const handleSave = async () => {
    setSaved(true);
    toast({ title: "Profile saved", description: "Your changes have been saved successfully." });
    setTimeout(() => setSaved(false), 2e3);
  };
  const handleKycSubmit = async () => {
    setKycSubmitting(true);
    await new Promise((r) => setTimeout(r, 1800));
    setKycSubmitting(false);
    setKycSubmitted(true);
    toast({
      title: "KYC Documents Submitted",
      description: "Our team will review your documents within 24 hours.",
    });
  };
  return (
    <motion.div variants={stagger} initial="hidden" animate="visible" className="space-y-6">
      <motion.div variants={fadeDown} custom={0}>
        <h1 className="font-display text-2xl font-bold text-foreground">Profile & Security</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Manage your account settings and security preferences
        </p>
      </motion.div>
      <div className="flex flex-col gap-6 lg:flex-row">
        {/* Sidebar Tabs */}
        <motion.div variants={fadeUp} custom={1} className="shrink-0 space-y-1 lg:w-56">
          {tabs.map(({ id, icon: Icon, label }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className={cn(
                "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all",
                activeTab === id
                  ? "border border-accent/20 bg-accent/10 text-accent"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground",
              )}
            >
              <Icon className="h-4 w-4 shrink-0" />
              {label}
              {id === "activity" && (
                <span className="ml-auto flex h-4 w-4 items-center justify-center rounded-full bg-destructive/80 text-[9px] font-bold text-destructive-foreground">
                  1
                </span>
              )}
            </button>
          ))}
        </motion.div>
        {/* Content */}
        <motion.div variants={fadeUp} custom={2} className="flex-1">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="min-h-[400px] rounded-2xl border border-border bg-card p-6 shadow-card"
            >
              {/* Profile Tab */}
              {activeTab === "profile" && (
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="gradient-card flex h-16 w-16 items-center justify-center rounded-full text-xl font-bold text-primary-foreground shadow-navy">
                      JD
                    </div>
                    <div>
                      <h3 className="font-display font-semibold text-foreground">John Doe</h3>
                      <p className="text-sm text-muted-foreground">john@example.com</p>
                      <div className="secure-badge mt-1 inline-flex">
                        <Check className="h-3 w-3" /> KYC Verified
                      </div>
                    </div>
                    <Button variant="outline" size="sm" className="ml-auto">
                      Change Photo
                    </Button>
                  </div>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    {[
                      { label: "First Name", value: "John", placeholder: "First name" },
                      { label: "Last Name", value: "Doe", placeholder: "Last name" },
                      { label: "Email", value: "john@example.com", placeholder: "Email" },
                      { label: "Phone", value: "+1 (555) 000-0001", placeholder: "Phone" },
                    ].map(({ label, value, placeholder }) => (
                      <div key={label}>
                        <Label className="text-xs font-medium text-foreground">{label}</Label>
                        <Input className="mt-1.5" defaultValue={value} placeholder={placeholder} />
                      </div>
                    ))}
                  </div>
                  <div className="space-y-3 border-t border-border pt-4">
                    <h4 className="text-sm font-semibold text-foreground">Notifications</h4>
                    {[
                      {
                        label: "Email notifications",
                        desc: "Security alerts and transaction updates",
                        state: emailNotif,
                        setState: setEmailNotif,
                      },
                      {
                        label: "SMS notifications",
                        desc: "OTP and urgent alerts",
                        state: smsNotif,
                        setState: setSmsNotif,
                      },
                    ].map(({ label, desc, state, setState }) => (
                      <div key={label} className="flex items-center justify-between py-2">
                        <div>
                          <p className="text-sm font-medium text-foreground">{label}</p>
                          <p className="text-xs text-muted-foreground">{desc}</p>
                        </div>
                        <Switch checked={state} onCheckedChange={setState} />
                      </div>
                    ))}
                  </div>
                  <Button variant="accent" className="shadow-glow" onClick={handleSave}>
                    {saved ? (
                      <>
                        <Check className="mr-2 h-4 w-4" /> Saved!
                      </>
                    ) : (
                      "Save Changes"
                    )}
                  </Button>
                </div>
              )}
              {/* 2FA Tab */}
              {activeTab === "2fa" && (
                <div className="space-y-5">
                  <div className="flex items-center justify-between rounded-xl border border-border bg-muted/50 p-4">
                    <div className="flex items-center gap-3">
                      <div
                        className={cn(
                          "flex h-10 w-10 items-center justify-center rounded-xl",
                          twoFaEnabled ? "gradient-accent" : "bg-muted",
                        )}
                      >
                        <Smartphone
                          className={cn(
                            "h-5 w-5",
                            twoFaEnabled ? "text-accent-foreground" : "text-muted-foreground",
                          )}
                        />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-foreground">
                          Two-Factor Authentication
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {twoFaEnabled
                            ? "Enabled \u2013 Your account is protected"
                            : "Disabled \u2013 Enable for better security"}
                        </p>
                      </div>
                    </div>
                    <Switch checked={twoFaEnabled} onCheckedChange={setTwoFaEnabled} />
                  </div>
                  {twoFaEnabled && (
                    <div className="animate-fade-in space-y-3">
                      {[
                        {
                          icon: Smartphone,
                          title: "Authenticator App",
                          desc: "Google Authenticator or Authy",
                          active: true,
                        },
                        {
                          icon: Key,
                          title: "SMS Verification",
                          desc: "+1 (555) \u2022\u2022\u2022\u2022 0001",
                          active: false,
                        },
                        {
                          icon: Shield,
                          title: "Backup Codes",
                          desc: "10 single-use codes",
                          active: false,
                        },
                      ].map(({ icon: Icon, title, desc, active }) => (
                        <div
                          key={title}
                          className={cn(
                            "flex items-center gap-3 rounded-xl border p-4 transition-colors",
                            active
                              ? "border-accent/40 bg-accent/5"
                              : "border-border hover:border-accent/30",
                          )}
                        >
                          <div
                            className={cn(
                              "flex h-9 w-9 items-center justify-center rounded-lg",
                              active ? "gradient-accent" : "bg-muted",
                            )}
                          >
                            <Icon
                              className={cn(
                                "h-4 w-4",
                                active ? "text-accent-foreground" : "text-muted-foreground",
                              )}
                            />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-semibold text-foreground">{title}</p>
                            <p className="text-xs text-muted-foreground">{desc}</p>
                          </div>
                          {active ? (
                            <span className="secure-badge text-xs">Active</span>
                          ) : (
                            <button className="text-xs text-accent hover:underline">Set up</button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                  <div className="space-y-3 border-t border-border pt-4">
                    <h3 className="font-display font-semibold text-foreground">Change Password</h3>
                    <div className="space-y-4">
                      <div>
                        <Label className="text-xs font-medium text-foreground">
                          Current Password
                        </Label>
                        <div className="relative mt-1.5">
                          <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                          <Input type="password" placeholder="••••••••" className="pl-10" />
                        </div>
                      </div>
                      <div>
                        <Label className="text-xs font-medium text-foreground">New Password</Label>
                        <div className="relative mt-1.5">
                          <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                          <Input
                            type={showPwd ? "text" : "password"}
                            placeholder="Min. 8 characters"
                            className="pl-10 pr-10"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPwd(!showPwd)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                          >
                            {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                      </div>
                    </div>
                    <Button variant="accent" className="shadow-glow">
                      Update Password
                    </Button>
                  </div>
                </div>
              )}
              {/* Activity Log */}
              {activeTab === "activity" && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-display font-semibold text-foreground">
                      Security Activity Log
                    </h3>
                    <Button variant="outline" size="sm">
                      Export Log
                    </Button>
                  </div>
                  <div className="space-y-3">
                    {activityLog.map((log, i) => (
                      <motion.div
                        key={log.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.07, duration: 0.35, ease: "easeOut" }}
                        className="flex items-start gap-3 rounded-xl border border-border p-3.5 transition-colors hover:bg-muted/30"
                      >
                        <div
                          className={cn(
                            "flex h-9 w-9 shrink-0 items-center justify-center rounded-xl",
                            log.risk === "low"
                              ? "bg-accent/15"
                              : log.risk === "medium"
                                ? "bg-warning/15"
                                : "bg-destructive/10",
                          )}
                        >
                          {log.risk === "high" ? (
                            <AlertTriangle className="h-4 w-4 text-destructive" />
                          ) : (
                            <Activity
                              className={cn(
                                "h-4 w-4",
                                log.risk === "low" ? "text-accent" : "text-warning",
                              )}
                            />
                          )}
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-semibold text-foreground">{log.action}</p>
                          <p className="text-xs text-muted-foreground">
                            {log.device} · {log.location}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">{log.time}</p>
                          {log.risk === "high" && (
                            <span className="badge-danger mt-0.5 inline-block rounded-full px-1.5 py-0.5 text-[10px] font-medium">
                              Suspicious
                            </span>
                          )}
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}
              {/* KYC Status */}
              {activeTab === "kyc" && (
                <div className="space-y-5">
                  <div className="gradient-accent rounded-xl p-5 text-accent-foreground shadow-glow">
                    <div className="mb-2 flex items-center gap-3">
                      <Check className="h-6 w-6" />
                      <h3 className="font-display text-lg font-bold">Identity Verified</h3>
                    </div>
                    <p className="text-sm text-accent-foreground/80">
                      Your account is fully verified. You have full access to all features.
                    </p>
                  </div>
                  {[
                    { label: "Government ID", status: "Verified", date: "Jun 12, 2025" },
                    { label: "Selfie / Liveness Check", status: "Verified", date: "Jun 12, 2025" },
                    { label: "Address Proof", status: "Verified", date: "Jun 15, 2025" },
                    { label: "Source of Funds", status: "Pending", date: "In review" },
                  ].map(({ label, status, date }) => (
                    <div
                      key={label}
                      className="flex items-center justify-between border-b border-border/50 py-3 last:border-0"
                    >
                      <div>
                        <p className="text-sm font-medium text-foreground">{label}</p>
                        <p className="text-xs text-muted-foreground">{date}</p>
                      </div>
                      <span
                        className={cn(
                          "rounded-full px-2.5 py-1 text-xs font-medium",
                          status === "Verified" ? "badge-success" : "badge-warning",
                        )}
                      >
                        {status}
                      </span>
                    </div>
                  ))}
                  {/* Upload National ID */}
                  <div className="space-y-4 border-t border-border pt-4">
                    <div>
                      <h4 className="mb-1 font-display font-semibold text-foreground">
                        Upload Identity Documents
                      </h4>
                      <p className="text-xs text-muted-foreground">
                        Upload your National ID or Passport for verification. All files are
                        encrypted and secure.
                      </p>
                    </div>
                    <KycFileUpload
                      label="National ID / Passport Photo (Front)"
                      onUpload={(f) => setKycUploads((u) => ({ ...u, front: f }))}
                    />
                    <KycFileUpload
                      label="National ID / Passport Photo (Back)"
                      onUpload={(f) => setKycUploads((u) => ({ ...u, back: f }))}
                    />
                    <KycFileUpload
                      label="Selfie with ID (Hold your ID next to your face)"
                      onUpload={(f) => setKycUploads((u) => ({ ...u, selfie: f }))}
                    />
                    <div className="flex items-center gap-2 rounded-xl border border-border bg-muted/50 p-3 text-xs text-muted-foreground">
                      <Shield className="h-3.5 w-3.5 shrink-0 text-accent" />
                      <span>
                        All documents are encrypted with 256-bit SSL and never shared with third
                        parties.
                      </span>
                    </div>
                    {kycSubmitted ? (
                      <div className="gradient-success flex items-center gap-3 rounded-xl p-4 text-accent-foreground shadow-glow">
                        <Check className="h-5 w-5 shrink-0" />
                        <div>
                          <p className="text-sm font-semibold">Documents Submitted Successfully</p>
                          <p className="text-xs text-accent-foreground/80">
                            Review typically takes 24–48 hours.
                          </p>
                        </div>
                      </div>
                    ) : (
                      <Button
                        variant="accent"
                        className="w-full shadow-glow"
                        disabled={Object.keys(kycUploads).length === 0 || kycSubmitting}
                        onClick={handleKycSubmit}
                      >
                        {kycSubmitting ? (
                          <div className="flex items-center gap-2">
                            <div className="h-4 w-4 animate-spin rounded-full border-2 border-accent-foreground/30 border-t-accent-foreground" />
                            Submitting...
                          </div>
                        ) : (
                          <>
                            <Upload className="mr-2 h-4 w-4" />
                            Submit Documents for Review
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </motion.div>
      </div>
    </motion.div>
  );
}
export { SettingsPage as default };
