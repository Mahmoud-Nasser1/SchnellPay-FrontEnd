import { useState } from "react";
import {
  Send,
  Download,
  Plus,
  CreditCard,
  TrendingUp,
  ArrowUpRight,
  ArrowDownLeft,
  Eye,
  EyeOff,
  Wallet,
  Shield,
  RefreshCw,
} from "lucide-react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts";
import { motion } from "framer-motion";
import { fadeUp, fadeDown, stagger, scaleIn } from "@/lib/motion";
const chartData = [
  { month: "Jan", income: 5200, expense: 2800 },
  { month: "Feb", income: 4800, expense: 3100 },
  { month: "Mar", income: 6200, expense: 2600 },
  { month: "Apr", income: 5900, expense: 3400 },
  { month: "May", income: 7100, expense: 3200 },
  { month: "Jun", income: 6800, expense: 2900 },
  { month: "Jul", income: 8200, expense: 3800 },
];
const recentTransactions = [
  {
    id: 1,
    name: "Salary Deposit",
    type: "credit",
    amount: 5200,
    date: "Jul 1",
    category: "Income",
    avatar: "SD",
    color: "from-success/80 to-success",
  },
  {
    id: 2,
    name: "Netflix",
    type: "debit",
    amount: 15.99,
    date: "Jul 2",
    category: "Entertainment",
    avatar: "NF",
    color: "from-destructive/70 to-destructive",
  },
  {
    id: 3,
    name: "Transfer to Alice",
    type: "debit",
    amount: 250,
    date: "Jul 3",
    category: "Transfer",
    avatar: "AL",
    color: "from-primary/80 to-primary",
  },
  {
    id: 4,
    name: "Amazon Purchase",
    type: "debit",
    amount: 89.99,
    date: "Jul 4",
    category: "Shopping",
    avatar: "AM",
    color: "from-warning/70 to-warning",
  },
  {
    id: 5,
    name: "Freelance Payment",
    type: "credit",
    amount: 1200,
    date: "Jul 5",
    category: "Income",
    avatar: "FP",
    color: "from-accent/80 to-accent",
  },
];
const quickActions = [
  {
    icon: Send,
    label: "Send",
    to: "/dashboard/send",
    bg: "bg-accent/10 hover:bg-accent group-hover:bg-accent",
    icon_color: "text-accent group-hover:text-accent-foreground",
    label_color: "text-accent group-hover:text-accent-foreground",
  },
  {
    icon: Download,
    label: "Receive",
    to: "/dashboard/receive",
    bg: "bg-primary/10 hover:bg-primary group-hover:bg-primary",
    icon_color: "text-primary dark:text-primary-foreground group-hover:text-primary-foreground",
    label_color: "text-primary dark:text-primary-foreground group-hover:text-primary-foreground",
  },
  {
    icon: Plus,
    label: "Add Money",
    to: "/dashboard/funds",
    bg: "bg-success/10 hover:bg-success group-hover:bg-success",
    icon_color: "text-success group-hover:text-success-foreground",
    label_color: "text-success group-hover:text-success-foreground",
  },
  {
    icon: CreditCard,
    label: "Pay Bills",
    to: "/dashboard/bills",
    bg: "bg-warning/10 hover:bg-warning group-hover:bg-warning",
    icon_color: "text-warning group-hover:text-warning-foreground",
    label_color: "text-warning group-hover:text-warning-foreground",
  },
];
function DashboardHome() {
  const [balanceHidden, setBalanceHidden] = useState(false);
  return (
    <motion.div
      variants={stagger}
      initial="hidden"
      animate="visible"
      className="max-w-6xl space-y-5"
    >
      {/* ── Page header ── */}
      <motion.div variants={fadeDown} custom={0} className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Good morning, John 👋</h1>
          <p className="mt-0.5 text-sm text-muted-foreground">
            Here's your financial overview for today.
          </p>
        </div>
        <button className="rounded-xl p-2.5 text-muted-foreground transition-all duration-150 hover:bg-muted hover:text-foreground">
          <RefreshCw className="h-4 w-4" />
        </button>
      </motion.div>
      {/* ── Balance Card + Quick Actions ── */}
      <motion.div variants={fadeUp} custom={1} className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Balance Card */}
        <div className="balance-card relative overflow-hidden rounded-2xl p-6 shadow-navy lg:col-span-2">
          <div className="relative z-10">
            <div className="mb-5 flex items-start justify-between">
              <div>
                <p className="mb-2 text-xs font-medium uppercase tracking-widest text-primary-foreground/60">
                  Total Balance
                </p>
                <div className="flex items-center gap-3">
                  <p className="font-display text-4xl font-bold tracking-tight text-primary-foreground">
                    {balanceHidden
                      ? "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
                      : "$48,250.00"}
                  </p>
                  <button
                    onClick={() => setBalanceHidden(!balanceHidden)}
                    className="p-1 text-primary-foreground/50 transition-colors hover:text-primary-foreground/90"
                    aria-label={balanceHidden ? "Show balance" : "Hide balance"}
                  >
                    {balanceHidden ? (
                      <Eye className="w-4.5 h-4.5" />
                    ) : (
                      <EyeOff className="w-4.5 h-4.5" />
                    )}
                  </button>
                </div>
                <div className="mt-2 flex items-center gap-1.5">
                  <TrendingUp className="h-3.5 w-3.5 text-accent" />
                  <span className="text-sm font-semibold text-accent">+12.4% this month</span>
                </div>
              </div>
              <div className="flex flex-col items-end gap-2 text-right">
                <div className="secure-badge">
                  <Shield className="h-3 w-3" /> Secured
                </div>
                <div className="gradient-accent flex h-11 w-11 items-center justify-center rounded-2xl shadow-glow">
                  <Wallet className="h-5 w-5 text-accent-foreground" />
                </div>
              </div>
            </div>
            {/* Sub-balances */}
            <div className="mt-4 grid grid-cols-3 gap-3 border-t border-primary-foreground/10 pt-4">
              {[
                { label: "Available", value: "$46,100.00" },
                { label: "Pending", value: "$2,150.00" },
                { label: "Savings", value: "$12,400.00" },
              ].map(({ label, value }) => (
                <div key={label}>
                  <p className="mb-1 text-[11px] uppercase tracking-wide text-primary-foreground/50">
                    {label}
                  </p>
                  <p className="text-sm font-semibold text-primary-foreground">
                    {balanceHidden ? "\u2022\u2022\u2022\u2022" : value}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
        {/* Quick Actions */}
        <div className="rounded-2xl border border-border bg-card p-5 shadow-card">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-display text-sm font-semibold text-foreground">Quick Actions</h3>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {quickActions.map(({ icon: Icon, label, to, bg, icon_color, label_color }) => (
              <Link
                key={label}
                to={to}
                className={cn(
                  "group flex flex-col items-center justify-center gap-2.5 rounded-2xl py-5",
                  "transition-all duration-200 hover:scale-[1.03] active:scale-[0.98]",
                  bg,
                )}
              >
                <Icon className={cn("h-5 w-5 transition-colors", icon_color)} />
                <span className={cn("text-xs font-semibold transition-colors", label_color)}>
                  {label}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </motion.div>
      {/* ── Stats Row ── */}
      <motion.div variants={stagger} className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          {
            label: "Income (Jul)",
            value: "$8,200",
            change: "+18%",
            up: true,
            icon: ArrowDownLeft,
            iconBg: "bg-success/10",
            iconColor: "text-success",
          },
          {
            label: "Expenses (Jul)",
            value: "$3,800",
            change: "+5%",
            up: false,
            icon: ArrowUpRight,
            iconBg: "bg-destructive/10",
            iconColor: "text-destructive",
          },
          {
            label: "Savings Rate",
            value: "53.7%",
            change: "+2.1%",
            up: true,
            icon: TrendingUp,
            iconBg: "bg-accent/10",
            iconColor: "text-accent",
          },
          {
            label: "Transactions",
            value: "47",
            change: "+12",
            up: true,
            icon: CreditCard,
            iconBg: "bg-warning/10",
            iconColor: "text-warning",
          },
        ].map((stat, i) => (
          <motion.div
            key={stat.label}
            variants={scaleIn}
            custom={i}
            className="rounded-2xl border border-border bg-card p-4 shadow-card transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lifted"
          >
            <div className="mb-3 flex items-start justify-between">
              <p className="text-xs font-medium leading-tight text-muted-foreground">
                {stat.label}
              </p>
              <div
                className={cn(
                  "flex h-7 w-7 shrink-0 items-center justify-center rounded-lg",
                  stat.iconBg,
                )}
              >
                <stat.icon className={cn("h-3.5 w-3.5", stat.iconColor)} />
              </div>
            </div>
            <p className="font-display text-xl font-bold text-foreground">{stat.value}</p>
            <p
              className={cn(
                "mt-1 text-xs font-medium",
                stat.up ? "text-success" : "text-destructive",
              )}
            >
              {stat.change} vs last month
            </p>
          </motion.div>
        ))}
      </motion.div>
      {/* ── Chart + Recent Transactions ── */}
      <motion.div variants={fadeUp} custom={3} className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Chart */}
        <div className="rounded-2xl border border-border bg-card p-5 shadow-card lg:col-span-2">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <h3 className="font-display font-semibold text-foreground">Income vs Expenses</h3>
              <p className="mt-0.5 text-xs text-muted-foreground">Last 7 months overview</p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <div className="flex items-center gap-1.5">
                <div className="h-2.5 w-2.5 rounded-full bg-accent" />
                <span className="font-medium text-muted-foreground">Income</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="h-2.5 w-2.5 rounded-full bg-destructive" />
                <span className="font-medium text-muted-foreground">Expenses</span>
              </div>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={chartData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="incomeGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(162 75% 28%)" stopOpacity={0.25} />
                  <stop offset="100%" stopColor="hsl(162 75% 28%)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="expenseGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(0 70% 48%)" stopOpacity={0.18} />
                  <stop offset="100%" stopColor="hsl(0 70% 48%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="hsl(var(--border))"
                strokeOpacity={0.6}
              />
              <XAxis
                dataKey="month"
                tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  background: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "0.75rem",
                  fontSize: "12px",
                  color: "hsl(var(--card-foreground))",
                  boxShadow: "var(--shadow-lg)",
                }}
                formatter={(v) => [`$${v.toLocaleString()}`, ""]}
                cursor={{ stroke: "hsl(var(--border))", strokeWidth: 1 }}
              />
              <Area
                type="monotone"
                dataKey="income"
                stroke="hsl(162 75% 28%)"
                strokeWidth={2.5}
                fill="url(#incomeGrad)"
                dot={false}
                activeDot={{
                  r: 4,
                  fill: "hsl(162 75% 28%)",
                  stroke: "hsl(var(--card))",
                  strokeWidth: 2,
                }}
              />
              <Area
                type="monotone"
                dataKey="expense"
                stroke="hsl(0 70% 48%)"
                strokeWidth={2}
                fill="url(#expenseGrad)"
                dot={false}
                activeDot={{
                  r: 4,
                  fill: "hsl(0 70% 48%)",
                  stroke: "hsl(var(--card))",
                  strokeWidth: 2,
                }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        {/* Recent Transactions */}
        <div className="rounded-2xl border border-border bg-card p-5 shadow-card">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="font-display text-sm font-semibold text-foreground">Recent</h3>
              <p className="mt-0.5 text-[11px] text-muted-foreground">Latest activity</p>
            </div>
            <Link
              to="/dashboard/transactions"
              className="text-xs font-semibold text-accent transition-colors hover:text-accent/80"
            >
              View all →
            </Link>
          </div>
          <div className="space-y-1">
            {recentTransactions.map((tx, i) => (
              <motion.div
                key={tx.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + i * 0.06, duration: 0.35, ease: "easeOut" }}
                className="group flex cursor-pointer items-center gap-3 rounded-xl p-2.5 transition-colors hover:bg-muted/60"
              >
                {/* Avatar */}
                <div
                  className={cn(
                    "flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-[10px] font-bold text-white",
                    `bg-gradient-to-br ${tx.color}`,
                  )}
                >
                  {tx.avatar}
                </div>
                {/* Info */}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-foreground">{tx.name}</p>
                  <p className="text-[11px] text-muted-foreground">
                    {tx.date} · {tx.category}
                  </p>
                </div>
                {/* Amount */}
                <span
                  className={cn(
                    "shrink-0 text-sm font-semibold tabular-nums",
                    tx.type === "credit" ? "text-success" : "text-foreground",
                  )}
                >
                  {tx.type === "credit" ? "+" : "\u2212"}${tx.amount.toLocaleString()}
                </span>
              </motion.div>
            ))}
          </div>
          <div className="mt-3 border-t border-border pt-3">
            <Link
              to="/dashboard/transactions"
              className="block py-1 text-center text-xs font-medium text-muted-foreground transition-colors hover:text-accent"
            >
              See all transactions
            </Link>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
export { DashboardHome as default };
