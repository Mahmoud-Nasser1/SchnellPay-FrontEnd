import { useState } from "react";
import { Search, Download, ArrowUpRight, ArrowDownLeft, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { fadeUp, fadeDown, scaleIn, stagger } from "@/lib/motion";
const transactions = [
  {
    id: "TXN-001",
    name: "Salary Deposit",
    type: "credit",
    amount: 5200,
    date: "Jul 1, 2025",
    category: "Income",
    status: "completed",
  },
  {
    id: "TXN-002",
    name: "Netflix Subscription",
    type: "debit",
    amount: 15.99,
    date: "Jul 2, 2025",
    category: "Entertainment",
    status: "completed",
  },
  {
    id: "TXN-003",
    name: "Transfer to Alice Johnson",
    type: "debit",
    amount: 250,
    date: "Jul 3, 2025",
    category: "Transfer",
    status: "completed",
  },
  {
    id: "TXN-004",
    name: "Amazon Purchase",
    type: "debit",
    amount: 89.99,
    date: "Jul 4, 2025",
    category: "Shopping",
    status: "completed",
  },
  {
    id: "TXN-005",
    name: "Freelance Payment from Bob",
    type: "credit",
    amount: 1200,
    date: "Jul 5, 2025",
    category: "Income",
    status: "completed",
  },
  {
    id: "TXN-006",
    name: "Electricity Bill",
    type: "debit",
    amount: 120.5,
    date: "Jul 6, 2025",
    category: "Utilities",
    status: "completed",
  },
  {
    id: "TXN-007",
    name: "Spotify Premium",
    type: "debit",
    amount: 9.99,
    date: "Jul 7, 2025",
    category: "Entertainment",
    status: "completed",
  },
  {
    id: "TXN-008",
    name: "Restaurant \u2013 The Oak",
    type: "debit",
    amount: 68,
    date: "Jul 8, 2025",
    category: "Food",
    status: "completed",
  },
  {
    id: "TXN-009",
    name: "PayPal Transfer",
    type: "credit",
    amount: 450,
    date: "Jul 9, 2025",
    category: "Transfer",
    status: "pending",
  },
  {
    id: "TXN-010",
    name: "Gym Membership",
    type: "debit",
    amount: 45,
    date: "Jul 10, 2025",
    category: "Health",
    status: "failed",
  },
];
const statusBadge = {
  completed: "badge-success",
  pending: "badge-warning",
  failed: "badge-danger",
};
function TransactionsPage() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [downloadLoading, setDownloadLoading] = useState(false);
  const filtered = transactions.filter((t) => {
    const matchSearch =
      t.name.toLowerCase().includes(search.toLowerCase()) ||
      t.id.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === "all" || t.type === filter;
    return matchSearch && matchFilter;
  });
  const handleDownload = async () => {
    setDownloadLoading(true);
    await new Promise((r) => setTimeout(r, 1500));
    setDownloadLoading(false);
  };
  return (
    <motion.div variants={stagger} initial="hidden" animate="visible" className="space-y-6">
      <motion.div
        variants={fadeDown}
        custom={0}
        className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center"
      >
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Transaction History</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            View and manage all your transactions
          </p>
        </div>
        <Button variant="outline" onClick={handleDownload} disabled={downloadLoading}>
          {downloadLoading ? (
            <div className="flex items-center gap-2">
              <div className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-muted-foreground/30 border-t-foreground" />
              Generating PDF...
            </div>
          ) : (
            <>
              <Download className="mr-2 h-4 w-4" />
              Download PDF
            </>
          )}
        </Button>
      </motion.div>
      {/* Filters */}
      <motion.div
        variants={fadeUp}
        custom={1}
        className="rounded-2xl border border-border bg-card p-4 shadow-card"
      >
        <div className="flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search transactions..."
              className="pl-10"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            {["all", "credit", "debit"].map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={cn(
                  "rounded-lg px-4 py-2 text-sm font-medium capitalize transition-all",
                  filter === f
                    ? "gradient-accent text-accent-foreground shadow-glow"
                    : "border border-border text-muted-foreground hover:border-accent/50 hover:text-foreground",
                )}
              >
                {f === "all" ? "All" : f === "credit" ? "Income" : "Expenses"}
              </button>
            ))}
          </div>
        </div>
      </motion.div>
      {/* Table */}
      <motion.div
        variants={fadeUp}
        custom={2}
        className="overflow-hidden rounded-2xl border border-border bg-card shadow-card"
      >
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                {["Transaction", "Category", "Date", "Status", "Amount"].map((h) => (
                  <th
                    key={h}
                    className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground"
                  >
                    <button className="flex items-center gap-1 transition-colors hover:text-foreground">
                      {h} <ChevronDown className="h-3 w-3" />
                    </button>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map((tx, i) => (
                <motion.tr
                  key={tx.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04, duration: 0.3, ease: "easeOut" }}
                  className="group transition-colors hover:bg-muted/30"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div
                        className={cn(
                          "flex h-9 w-9 shrink-0 items-center justify-center rounded-xl",
                          tx.type === "credit" ? "bg-accent/15" : "bg-destructive/10",
                        )}
                      >
                        {tx.type === "credit" ? (
                          <ArrowDownLeft className="h-4 w-4 text-accent" />
                        ) : (
                          <ArrowUpRight className="h-4 w-4 text-destructive" />
                        )}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-foreground">{tx.name}</p>
                        <p className="text-xs text-muted-foreground">{tx.id}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="rounded-full bg-muted px-2.5 py-1 text-xs font-medium text-muted-foreground">
                      {tx.category}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{tx.date}</td>
                  <td className="px-4 py-3">
                    <span
                      className={cn(
                        "rounded-full px-2.5 py-1 text-xs font-medium capitalize",
                        statusBadge[tx.status],
                      )}
                    >
                      {tx.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={cn(
                        "text-sm font-semibold",
                        tx.type === "credit" ? "text-accent" : "text-foreground",
                      )}
                    >
                      {tx.type === "credit" ? "+" : "-"}${tx.amount.toLocaleString()}
                    </span>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <motion.div
            variants={scaleIn}
            initial="hidden"
            animate="visible"
            className="py-12 text-center text-muted-foreground"
          >
            <p className="font-medium">No transactions found</p>
            <p className="mt-1 text-sm">Try adjusting your filters</p>
          </motion.div>
        )}
        <div className="flex items-center justify-between border-t border-border px-4 py-3 text-sm text-muted-foreground">
          <span>
            Showing {filtered.length} of {transactions.length} transactions
          </span>
          <div className="flex gap-2">
            <button className="rounded-lg border border-border px-3 py-1.5 text-xs transition-colors hover:bg-muted">
              Previous
            </button>
            <button className="rounded-lg border border-border px-3 py-1.5 text-xs transition-colors hover:bg-muted">
              Next
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
export { TransactionsPage as default };
