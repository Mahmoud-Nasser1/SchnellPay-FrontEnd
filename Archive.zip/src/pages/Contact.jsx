import {
  Mail,
  Phone,
  MapPin,
  Send,
  Clock,
  Shield,
  MessageSquare,
  HeadphonesIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState, useRef } from "react";
import PublicNav from "@/components/PublicNav";
import PublicFooter from "@/components/PublicFooter";
import { motion, useScroll, useTransform } from "framer-motion";
import {
  fadeUp,
  fadeDown,
  fadeIn,
  fadeLeft,
  fadeRight,
  scaleIn,
  stagger,
  viewport,
} from "@/lib/motion";
const contactInfo = [
  {
    icon: Mail,
    label: "Email Support",
    value: "support@securewallet.io",
    desc: "We reply within 2 hours",
  },
  {
    icon: Phone,
    label: "Phone",
    value: "+1 (888) 000-WALLET",
    desc: "Mon\u2013Fri, 9am\u20136pm ET",
  },
  {
    icon: MapPin,
    label: "Headquarters",
    value: "123 Fintech Ave, San Francisco",
    desc: "CA 94102, United States",
  },
  {
    icon: Clock,
    label: "Business Hours",
    value: "Mon\u2013Fri: 9am \u2013 6pm ET",
    desc: "Emergency support: 24/7",
  },
];
const supportOptions = [
  {
    icon: MessageSquare,
    title: "Live Chat",
    desc: "Chat with our team in real-time",
    badge: "Online now",
    color: "text-emerald-500 bg-emerald-500/10",
  },
  {
    icon: HeadphonesIcon,
    title: "Phone Support",
    desc: "Speak to a specialist directly",
    badge: "< 2 min wait",
    color: "text-blue-500 bg-blue-500/10",
  },
  {
    icon: Mail,
    title: "Email Us",
    desc: "Get a detailed written response",
    badge: "< 2 hr reply",
    color: "text-purple-500 bg-purple-500/10",
  },
  {
    icon: Shield,
    title: "Security Team",
    desc: "Report vulnerabilities safely",
    badge: "Encrypted",
    color: "text-orange-500 bg-orange-500/10",
  },
];
function ContactPage() {
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const heroY = useTransform(scrollYProgress, [0, 1], [0, 100]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1500));
    setLoading(false);
    setSent(true);
  };
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <PublicNav />
      <main className="flex-1 pt-16">
        {/* ── HERO ── */}
        <section
          ref={heroRef}
          className="gradient-hero relative flex min-h-[65vh] items-center overflow-hidden"
        >
          <motion.div style={{ y: heroY }} className="pointer-events-none absolute inset-0">
            <div
              className="absolute inset-0 opacity-[0.03]"
              style={{
                backgroundImage:
                  "linear-gradient(hsl(0 0% 100%) 1px, transparent 1px), linear-gradient(90deg, hsl(0 0% 100%) 1px, transparent 1px)",
                backgroundSize: "48px 48px",
              }}
            />
            <div
              className="absolute left-10 top-20 h-[400px] w-[400px] animate-pulse-glow rounded-full opacity-[0.10]"
              style={{ background: "radial-gradient(circle, hsl(162 90% 44%), transparent)" }}
            />
            <div
              className="absolute bottom-0 right-0 h-[350px] w-[350px] rounded-full opacity-[0.07]"
              style={{ background: "radial-gradient(circle, hsl(213 85% 50%), transparent)" }}
            />
          </motion.div>
          <div className="container relative z-10 mx-auto px-4 py-32">
            <motion.div
              style={{ opacity: heroOpacity }}
              variants={stagger}
              initial="hidden"
              animate="visible"
              className="mx-auto max-w-3xl text-center"
            >
              <motion.div
                variants={fadeDown}
                custom={0}
                className="mb-6 inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/10 px-4 py-2"
              >
                <HeadphonesIcon className="h-3.5 w-3.5 text-accent" />
                <span className="text-xs font-semibold uppercase tracking-wide text-accent">
                  24/7 Support Available
                </span>
              </motion.div>
              <motion.h1
                variants={fadeUp}
                custom={1}
                className="mb-6 font-display text-5xl font-bold leading-[1.05] text-primary-foreground md:text-7xl"
              >
                We're here to <span className="text-gradient-accent">help you</span>
              </motion.h1>
              <motion.p
                variants={fadeUp}
                custom={2}
                className="mx-auto mb-8 max-w-xl text-xl leading-relaxed text-primary-foreground/70"
              >
                Our world-class support team is available around the clock. Get answers fast.
              </motion.p>
              <motion.div
                variants={fadeUp}
                custom={3}
                className="flex flex-wrap justify-center gap-3"
              >
                {[
                  "\u26A1 Avg. 2-min response",
                  "\u{1F30D} 24/7 global support",
                  "\u{1F512} Secure & private",
                ].map((item) => (
                  <span
                    key={item}
                    className="rounded-full border border-primary-foreground/20 bg-primary-foreground/10 px-4 py-2 text-sm text-primary-foreground/80"
                  >
                    {item}
                  </span>
                ))}
              </motion.div>
            </motion.div>
          </div>
        </section>
        {/* ── SUPPORT OPTIONS ── */}
        <section className="border-b border-border bg-background py-16">
          <div className="container mx-auto px-4">
            <motion.div
              variants={stagger}
              initial="hidden"
              whileInView="visible"
              viewport={viewport}
              className="mx-auto grid max-w-5xl grid-cols-2 gap-4 md:grid-cols-4"
            >
              {supportOptions.map(({ icon: Icon, title, desc, badge, color }, i) => (
                <motion.div
                  key={title}
                  variants={scaleIn}
                  custom={i}
                  className="group cursor-pointer rounded-2xl border border-border bg-card p-5 text-center transition-all duration-300 hover:-translate-y-1 hover:shadow-lifted"
                >
                  <div
                    className={`h-12 w-12 rounded-xl ${color} mx-auto mb-3 flex items-center justify-center transition-transform duration-300 group-hover:scale-110`}
                  >
                    <Icon className="h-6 w-6" />
                  </div>
                  <h3 className="mb-1 text-sm font-semibold text-foreground">{title}</h3>
                  <p className="mb-2 text-xs text-muted-foreground">{desc}</p>
                  <span className="rounded-full border border-accent/20 bg-accent/10 px-2 py-0.5 text-[10px] font-semibold text-accent">
                    {badge}
                  </span>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>
        {/* ── MAIN SECTION ── */}
        <section className="bg-secondary/30 py-24">
          <div className="container mx-auto max-w-6xl px-4">
            <div className="grid grid-cols-1 gap-12 lg:grid-cols-5">
              {/* Contact Info */}
              <motion.div
                variants={fadeLeft}
                initial="hidden"
                whileInView="visible"
                viewport={viewport}
                className="space-y-6 lg:col-span-2"
              >
                <div>
                  <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-accent/20 bg-accent/10 px-3 py-1.5">
                    <Phone className="h-3 w-3 text-accent" />
                    <span className="text-xs font-semibold uppercase tracking-wide text-accent">
                      Contact Details
                    </span>
                  </div>
                  <h2 className="mb-3 font-display text-3xl font-bold text-foreground">
                    Get in touch
                  </h2>
                  <p className="leading-relaxed text-muted-foreground">
                    Choose the channel that works best for you. Our team is always ready to assist.
                  </p>
                </div>
                <div className="space-y-4">
                  {contactInfo.map(({ icon: Icon, label, value, desc }, i) => (
                    <motion.div
                      key={label}
                      variants={fadeUp}
                      custom={i}
                      className="flex items-start gap-4 rounded-xl border border-border bg-card p-4 transition-all duration-300 hover:border-accent/30 hover:shadow-card"
                    >
                      <div className="gradient-accent flex h-10 w-10 shrink-0 items-center justify-center rounded-xl shadow-glow">
                        <Icon className="h-5 w-5 text-accent-foreground" />
                      </div>
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-wide text-accent">
                          {label}
                        </p>
                        <p className="mt-0.5 text-sm font-medium text-foreground">{value}</p>
                        <p className="text-xs text-muted-foreground">{desc}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
                {/* Map placeholder */}
                <motion.div
                  variants={scaleIn}
                  custom={0}
                  className="relative h-40 w-full overflow-hidden rounded-2xl border border-border bg-card"
                >
                  <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-primary/5 to-accent/5">
                    <div className="text-center">
                      <MapPin className="mx-auto mb-2 h-8 w-8 text-accent" />
                      <p className="text-xs font-medium text-foreground">San Francisco, CA</p>
                      <p className="text-xs text-muted-foreground">123 Fintech Avenue</p>
                    </div>
                  </div>
                  <div
                    className="absolute inset-0 opacity-[0.04]"
                    style={{
                      backgroundImage:
                        "linear-gradient(hsl(var(--foreground)) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--foreground)) 1px, transparent 1px)",
                      backgroundSize: "24px 24px",
                    }}
                  />
                </motion.div>
              </motion.div>
              {/* Contact Form */}
              <motion.div
                variants={fadeRight}
                initial="hidden"
                whileInView="visible"
                viewport={viewport}
                className="rounded-2xl border border-border bg-card p-8 shadow-card lg:col-span-3"
              >
                {sent ? (
                  <motion.div
                    variants={stagger}
                    initial="hidden"
                    animate="visible"
                    className="py-16 text-center"
                  >
                    <motion.div
                      variants={scaleIn}
                      custom={0}
                      className="gradient-success mx-auto mb-6 flex h-20 w-20 animate-bounce-in items-center justify-center rounded-full shadow-glow"
                    >
                      <Send className="h-10 w-10 text-accent-foreground" />
                    </motion.div>
                    <motion.h3
                      variants={fadeUp}
                      custom={1}
                      className="mb-3 font-display text-2xl font-bold text-foreground"
                    >
                      Message Sent!
                    </motion.h3>
                    <motion.p variants={fadeUp} custom={2} className="mb-2 text-muted-foreground">
                      We've received your message and will reply within 2 hours.
                    </motion.p>
                    <motion.p
                      variants={fadeUp}
                      custom={3}
                      className="text-sm text-muted-foreground"
                    >
                      Check your email for a confirmation.
                    </motion.p>
                    <motion.div variants={fadeUp} custom={4}>
                      <Button
                        variant="accent"
                        className="mt-6 shadow-glow"
                        onClick={() => setSent(false)}
                      >
                        Send another message
                      </Button>
                    </motion.div>
                  </motion.div>
                ) : (
                  <motion.form
                    variants={stagger}
                    initial="hidden"
                    animate="visible"
                    onSubmit={handleSubmit}
                    className="space-y-5"
                  >
                    <motion.div variants={fadeDown} custom={0}>
                      <h3 className="mb-1 font-display text-2xl font-bold text-foreground">
                        Send us a message
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        We'll get back to you within 2 hours.
                      </p>
                    </motion.div>
                    <motion.div
                      variants={fadeUp}
                      custom={1}
                      className="grid grid-cols-1 gap-4 sm:grid-cols-2"
                    >
                      <div>
                        <Label className="text-xs font-medium text-foreground">First Name</Label>
                        <Input className="mt-1.5 h-11" placeholder="John" required />
                      </div>
                      <div>
                        <Label className="text-xs font-medium text-foreground">Last Name</Label>
                        <Input className="mt-1.5 h-11" placeholder="Doe" required />
                      </div>
                    </motion.div>
                    <motion.div variants={fadeUp} custom={2}>
                      <Label className="text-xs font-medium text-foreground">Email Address</Label>
                      <Input
                        type="email"
                        className="mt-1.5 h-11"
                        placeholder="you@example.com"
                        required
                      />
                    </motion.div>
                    <motion.div variants={fadeUp} custom={3}>
                      <Label className="text-xs font-medium text-foreground">Subject</Label>
                      <Input className="mt-1.5 h-11" placeholder="How can we help?" required />
                    </motion.div>
                    <motion.div variants={fadeUp} custom={4}>
                      <Label className="text-xs font-medium text-foreground">Message</Label>
                      <textarea
                        className="mt-1.5 h-32 w-full resize-none rounded-xl border border-input bg-background px-4 py-3 text-sm text-foreground transition-all focus:outline-none focus:ring-2 focus:ring-ring/50"
                        placeholder="Tell us more about your inquiry..."
                        required
                      />
                    </motion.div>
                    <motion.div variants={fadeUp} custom={5}>
                      <Button
                        type="submit"
                        variant="accent"
                        size="lg"
                        className="h-12 w-full text-base shadow-glow"
                        disabled={loading}
                      >
                        {loading ? (
                          <div className="flex items-center gap-2">
                            <div className="h-4 w-4 animate-spin rounded-full border-2 border-accent-foreground/30 border-t-accent-foreground" />
                            Sending...
                          </div>
                        ) : (
                          <>
                            <Send className="mr-2 h-4 w-4" />
                            Send Message
                          </>
                        )}
                      </Button>
                    </motion.div>
                    <motion.p
                      variants={fadeIn}
                      custom={6}
                      className="text-center text-xs text-muted-foreground"
                    >
                      <Shield className="mr-1 inline h-3 w-3 text-accent" />
                      Your message is encrypted and private.
                    </motion.p>
                  </motion.form>
                )}
              </motion.div>
            </div>
          </div>
        </section>
      </main>
      <PublicFooter />
    </div>
  );
}
export { ContactPage as default };
